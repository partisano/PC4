﻿Imports System.Data.SqlClient
Imports Entidades
Public Class clsAsignaturaD
    Inherits clsConexion
    Public Sub registrarasignaturaD(asignatura As Entidades.clsAsignaturaE)
        Try
            Dim Comando As New SqlCommand("registrarasignatura", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            Comando.Parameters.Add("@Nombre", SqlDbType.VarChar).Value = asignatura.Nombre1
            Comando.Parameters.Add("@Creditos", SqlDbType.Int).Value = asignatura.Creditos1
            Comando.Parameters.Add("@Tipo", SqlDbType.VarChar).Value = asignatura.Tipo1
            Comando.Parameters.Add("@Ciclo", SqlDbType.VarChar).Value = asignatura.Ciclo1
            MyBase.MsConn1.Open()
            Comando.ExecuteNonQuery()
            MyBase.MsConn1.Close()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Function listarasignaturaD() As DataTable
        Try
            Dim Resultado As SqlDataReader
            Dim Tabla As New DataTable
            Dim Comando As New SqlCommand("listarasignatura", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            MyBase.MsConn1.Open()
            Resultado = Comando.ExecuteReader()
            Tabla.Load(Resultado)
            MyBase.MsConn1.Close()
            Return Tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
    Public Sub modificarasignaturaD(asignatura As Entidades.clsAsignaturaE)
        Try
            Dim Comando As New SqlCommand("modificarasignatura", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            Comando.Parameters.Add("@Nombre", SqlDbType.VarChar).Value = asignatura.Nombre1
            Comando.Parameters.Add("@Creditos", SqlDbType.Int).Value = asignatura.Creditos1
            Comando.Parameters.Add("@Tipo", SqlDbType.VarChar).Value = asignatura.Tipo1
            Comando.Parameters.Add("@Ciclo", SqlDbType.VarChar).Value = asignatura.Ciclo1
            Comando.Parameters.Add("@idAsignatura", SqlDbType.Int).Value = asignatura.IdAsignatura1
            MyBase.MsConn1.Open()
            Comando.ExecuteNonQuery()
            MyBase.MsConn1.Close()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Sub eliminarasignaturaD(asignatura As Entidades.clsAsignaturaE)
        Try
            Dim Comando As New SqlCommand("eliminarasignatura", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            Comando.Parameters.Add("@idAsignatura", SqlDbType.Int).Value = asignatura.IdAsignatura1
            MyBase.MsConn1.Open()
            Comando.ExecuteNonQuery()
            MyBase.MsConn1.Close()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Function buscarasignaturaD(asignatura As Entidades.clsAsignaturaE) As DataTable
        Try
            Dim Resultado As SqlDataReader
            Dim Tabla As New DataTable
            Dim Comando As New SqlCommand("buscarasignatura", MyBase.MsConn1)
            Comando.Parameters.Add("@parabuscar", SqlDbType.VarChar).Value = asignatura.Busqueda1
            Comando.CommandType = CommandType.StoredProcedure
            MyBase.MsConn1.Open()
            Resultado = Comando.ExecuteReader()
            Tabla.Load(Resultado)
            MyBase.MsConn1.Close()
            Return Tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
End Class
