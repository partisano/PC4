﻿Imports System.Configuration
Imports System.Data.SqlClient

Public Class clsConexion
    Private usuario As String
    Private clave As String
    Private servidor As String
    Private base As String
    Private autent As Boolean = True 'True = autenticacion sql server False = autenticacion mixta
    Private msConn As SqlConnection

    Public Property Usuario1 As String
        Get
            Return usuario
        End Get
        Set(value As String)
            usuario = value
        End Set
    End Property

    Public Property Clave1 As String
        Get
            Return clave
        End Get
        Set(value As String)
            clave = value
        End Set
    End Property

    Public Property Servidor1 As String
        Get
            Return servidor
        End Get
        Set(value As String)
            servidor = value
        End Set
    End Property

    Public Property Base1 As String
        Get
            Return base
        End Get
        Set(value As String)
            base = value
        End Set
    End Property

    Public Property Autent1 As Boolean
        Get
            Return autent
        End Get
        Set(value As Boolean)
            autent = value
        End Set
    End Property

    Public Property MsConn1 As SqlConnection
        Get
            Return msConn
        End Get
        Set(value As SqlConnection)
            msConn = value
        End Set
    End Property


    Public Sub New()        'constructor
        Me.msConn = New SqlConnection(CadenaConexion)
    End Sub

    Private Function CadenaConexion() As String
        Try
            Dim strCon As String
            strCon = ConfigurationManager.ConnectionStrings("conmatriculaBD").ConnectionString
            Return strCon
        Catch ex As Exception
            Throw ex
        End Try
    End Function
End Class
