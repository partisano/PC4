﻿Imports System.Data.SqlClient
Imports Entidades
Public Class clsaulaD
    Inherits clsConexion
    Public Sub registraraulaD(aula As Entidades.clsAulaE)
        Try
            Dim Comando As New SqlCommand("registraraula", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            Comando.Parameters.Add("@Nombre", SqlDbType.VarChar).Value = aula.Nombre1
            Comando.Parameters.Add("@Vacantes", SqlDbType.Int).Value = aula.Vacantes1
            Comando.Parameters.Add("@idGrupo", SqlDbType.Int).Value = aula.IdGrupo1
            MyBase.MsConn1.Open()
            Comando.ExecuteNonQuery()
            MyBase.MsConn1.Close()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Function listaraulaD() As DataTable
        Try
            Dim Resultado As SqlDataReader
            Dim Tabla As New DataTable
            Dim Comando As New SqlCommand("listaraula", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            MyBase.MsConn1.Open()
            Resultado = Comando.ExecuteReader()
            Tabla.Load(Resultado)
            MyBase.MsConn1.Close()
            Return Tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
    Public Sub modificaraulaD(aula As Entidades.clsAulaE)
        Try
            Dim Comando As New SqlCommand("modificaraula", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            Comando.Parameters.Add("@idAula", SqlDbType.Int).Value = aula.IdAula1
            Comando.Parameters.Add("@Nombre", SqlDbType.VarChar).Value = aula.Nombre1
            Comando.Parameters.Add("@Vacantes", SqlDbType.Int).Value = aula.Vacantes1
            Comando.Parameters.Add("@idGrupo", SqlDbType.Int).Value = aula.IdGrupo1
            MyBase.MsConn1.Open()
            Comando.ExecuteNonQuery()
            MyBase.MsConn1.Close()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Sub eliminaraulaD(aula As Entidades.clsAulaE)
        Try
            Dim Comando As New SqlCommand("eliminaraula", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            Comando.Parameters.Add("@IdAula", SqlDbType.Int).Value = aula.IdAula1
            MyBase.MsConn1.Open()
            Comando.ExecuteNonQuery()
            MyBase.MsConn1.Close()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Function buscaraulaD(aula As Entidades.clsAulaE) As DataTable
        Try
            Dim Resultado As SqlDataReader
            Dim Tabla As New DataTable
            Dim Comando As New SqlCommand("buscaraula", MyBase.MsConn1)
            Comando.Parameters.Add("@parabuscar", SqlDbType.VarChar).Value = aula.Busqueda1
            Comando.CommandType = CommandType.StoredProcedure
            MyBase.MsConn1.Open()
            Resultado = Comando.ExecuteReader()
            Tabla.Load(Resultado)
            MyBase.MsConn1.Close()
            Return Tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
End Class
