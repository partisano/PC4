﻿Imports System.Data.SqlClient
Imports Entidades
Public Class clscalificacionD
    Inherits clsConexion
    Public Sub registrarcalificacionD(calificacion As Entidades.clscalificacionE)
        Try
            Dim Comando As New SqlCommand("registrarcalificacion", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            Comando.Parameters.Add("@idmatricula", SqlDbType.Int).Value = calificacion.Idmatricula1
            Comando.Parameters.Add("@idtipoevaluacion", SqlDbType.Int).Value = calificacion.Idtipoevaluacion1
            Comando.Parameters.Add("@nota", SqlDbType.Decimal).Value = calificacion.Nota1
            MyBase.MsConn1.Open()
            Comando.ExecuteNonQuery()
            MyBase.MsConn1.Close()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

End Class
