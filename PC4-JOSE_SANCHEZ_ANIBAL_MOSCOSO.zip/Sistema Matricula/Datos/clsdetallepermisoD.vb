﻿Imports System.Data.SqlClient
Imports Entidades
Public Class clsdetallepermisoD
    Inherits clsConexion
    Public Sub registrardetallepermisoD(detallepermiso As Entidades.clsdetallepermisoE)
        Try
            Dim Comando As New SqlCommand("registrardetallepermiso", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            Comando.Parameters.Add("@idelemento", SqlDbType.Int).Value = detallepermiso.Idelemento1
            Comando.Parameters.Add("@idtipousuario", SqlDbType.Int).Value = detallepermiso.Idtipousuario1
            MyBase.MsConn1.Open()
            Comando.ExecuteNonQuery()

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Function listardetallepermisoD() As DataTable
        Try
            Dim Resultado As SqlDataReader
            Dim Tabla As New DataTable
            Dim Comando As New SqlCommand("listardetallepermiso", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            MyBase.MsConn1.Open()
            Resultado = Comando.ExecuteReader()
            Tabla.Load(Resultado)
            MyBase.MsConn1.Close()
            Return Tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Public Sub eliminardetallepermisoD(detallepermiso As Entidades.clsdetallepermisoE)
        Try
            Dim Comando As New SqlCommand("eliminardetallepermiso", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            Comando.Parameters.Add("@idtipousuario", SqlDbType.Int).Value = detallepermiso.Idtipousuario1

            MyBase.MsConn1.Open()
            Comando.ExecuteNonQuery()
            MyBase.MsConn1.Close()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Function buscardetallepermisoD(detallepermiso As Entidades.clsdetallepermisoE) As DataTable
        Try
            Dim Resultado As SqlDataReader
            Dim Tabla As New DataTable
            Dim Comando As New SqlCommand("buscardetallepermiso", MyBase.MsConn1)
            Comando.Parameters.Add("@idtipousuario", SqlDbType.Int).Value = detallepermiso.Idtipousuario1
            Comando.CommandType = CommandType.StoredProcedure
            MyBase.MsConn1.Open()
            Resultado = Comando.ExecuteReader()
            Tabla.Load(Resultado)
            MyBase.MsConn1.Close()
            Return Tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
End Class
