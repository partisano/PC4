﻿Imports System.Data.SqlClient
Imports Entidades
Public Class clsestudianteD
    Inherits clsConexion
    Public Sub registrarestudianteD(estudiante As Entidades.clsEstudianteE)
        Try
            Dim Comando As New SqlCommand("registrarestudiante", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            Comando.Parameters.Add("@Nombres", SqlDbType.VarChar).Value = estudiante.Nombres1
            Comando.Parameters.Add("@Apellidos", SqlDbType.VarChar).Value = estudiante.Apellidos1
            Comando.Parameters.Add("@Email", SqlDbType.VarChar).Value = estudiante.Email1
            Comando.Parameters.Add("@Telefono", SqlDbType.VarChar).Value = estudiante.Telefono1
            Comando.Parameters.Add("@Fechanac", SqlDbType.Date).Value = estudiante.FechaNac1
            Comando.Parameters.Add("@Sexo", SqlDbType.Char).Value = estudiante.Sexo1
            Comando.Parameters.Add("@Semestreingreso", SqlDbType.VarChar).Value = estudiante.Semestreingreso1
            MyBase.MsConn1.Open()
            Comando.ExecuteNonQuery()
            MyBase.MsConn1.Close()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Function listarestudianteD() As DataTable
        Try
            Dim Resultado As SqlDataReader
            Dim Tabla As New DataTable
            Dim Comando As New SqlCommand("listarestudiante", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            MyBase.MsConn1.Open()
            Resultado = Comando.ExecuteReader()
            Tabla.Load(Resultado)
            MyBase.MsConn1.Close()
            Return Tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
    Public Sub modificarestudianteD(estudiante As Entidades.clsEstudianteE)
        Try
            Dim Comando As New SqlCommand("modificarestudiante", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            Comando.Parameters.Add("@idEstudiante", SqlDbType.Int).Value = estudiante.IdEstudiante1
            Comando.Parameters.Add("@Nombres", SqlDbType.VarChar).Value = estudiante.Nombres1
            Comando.Parameters.Add("@Apellidos", SqlDbType.VarChar).Value = estudiante.Apellidos1
            Comando.Parameters.Add("@Email", SqlDbType.VarChar).Value = estudiante.Email1
            Comando.Parameters.Add("@Telefono", SqlDbType.VarChar).Value = estudiante.Telefono1
            Comando.Parameters.Add("@Fechanac", SqlDbType.Date).Value = estudiante.FechaNac1
            Comando.Parameters.Add("@Sexo", SqlDbType.Char).Value = estudiante.Sexo1
            Comando.Parameters.Add("@Semestreingreso", SqlDbType.VarChar).Value = estudiante.Semestreingreso1
            MyBase.MsConn1.Open()
            Comando.ExecuteNonQuery()
            MyBase.MsConn1.Close()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Sub eliminarestudianteD(estudiante As Entidades.clsEstudianteE)
        Try
            Dim Comando As New SqlCommand("eliminarestudiante", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            Comando.Parameters.Add("@idEstudiante", SqlDbType.Int).Value = estudiante.IdEstudiante1
            MyBase.MsConn1.Open()
            Comando.ExecuteNonQuery()
            MyBase.MsConn1.Close()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Function buscarestudianteD(estudiante As Entidades.clsEstudianteE) As DataTable
        Try
            Dim Resultado As SqlDataReader
            Dim Tabla As New DataTable
            Dim Comando As New SqlCommand("buscarestudiante", MyBase.MsConn1)
            Comando.Parameters.Add("@parabuscar", SqlDbType.VarChar).Value = estudiante.Busqueda1
            Comando.CommandType = CommandType.StoredProcedure
            MyBase.MsConn1.Open()
            Resultado = Comando.ExecuteReader()
            Tabla.Load(Resultado)
            MyBase.MsConn1.Close()
            Return Tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
End Class
