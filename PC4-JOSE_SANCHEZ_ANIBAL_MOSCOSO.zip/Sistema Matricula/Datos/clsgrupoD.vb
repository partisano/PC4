﻿Imports System.Data.SqlClient
Imports Entidades
Public Class clsgrupoD
    Inherits clsConexion
    Public Sub registrargrupoD(grupo As Entidades.clsGrupoE)
        Try
            Dim Comando As New SqlCommand("registrargrupo", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            Comando.Parameters.Add("@Letra", SqlDbType.Char).Value = grupo.Letra1
            MyBase.MsConn1.Open()
            Comando.ExecuteNonQuery()
            MyBase.MsConn1.Close()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Function listargrupoD() As DataTable
        Try
            Dim Resultado As SqlDataReader
            Dim Tabla As New DataTable
            Dim Comando As New SqlCommand("listargrupo", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            MyBase.MsConn1.Open()
            Resultado = Comando.ExecuteReader()
            Tabla.Load(Resultado)
            MyBase.MsConn1.Close()
            Return Tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
    Public Sub modificargrupoD(grupo As Entidades.clsGrupoE)
        Try
            Dim Comando As New SqlCommand("modificargrupo", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            Comando.Parameters.Add("@Letra", SqlDbType.Char).Value = grupo.Letra1
            Comando.Parameters.Add("@idGrupo", SqlDbType.Int).Value = grupo.IdGrupo1
            MyBase.MsConn1.Open()
            Comando.ExecuteNonQuery()
            MyBase.MsConn1.Close()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Sub eliminargrupoD(grupo As Entidades.clsGrupoE)
        Try
            Dim Comando As New SqlCommand("eliminargrupo", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            Comando.Parameters.Add("@idGrupo", SqlDbType.Int).Value = grupo.IdGrupo1
            MyBase.MsConn1.Open()
            Comando.ExecuteNonQuery()
            MyBase.MsConn1.Close()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Function buscargrupoD(grupo As Entidades.clsGrupoE) As DataTable
        Try
            Dim Resultado As SqlDataReader
            Dim Tabla As New DataTable
            Dim Comando As New SqlCommand("buscargrupo", MyBase.MsConn1)
            Comando.Parameters.Add("@parabuscar", SqlDbType.VarChar).Value = grupo.Busqueda1
            Comando.CommandType = CommandType.StoredProcedure
            MyBase.MsConn1.Open()
            Resultado = Comando.ExecuteReader()
            Tabla.Load(Resultado)
            MyBase.MsConn1.Close()
            Return Tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
End Class
