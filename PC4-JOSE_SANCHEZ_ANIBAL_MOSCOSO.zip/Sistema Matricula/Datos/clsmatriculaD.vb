﻿Imports System.Data.SqlClient
Imports Entidades
Public Class clsmatriculaD
    Inherits clsConexion
    Public Sub registrarmatriculaD(matricula As Entidades.clsMatriculaE)
        Try
            Dim Comando As New SqlCommand("registrarmatricula", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            Comando.Parameters.Add("@Fechamatricula", SqlDbType.Date).Value = matricula.Fechamatricula1
            Comando.Parameters.Add("@idEstudiante", SqlDbType.Int).Value = matricula.IdEstudiante1
            Comando.Parameters.Add("@idAsignatura", SqlDbType.Int).Value = matricula.IdAsignatura1
            Comando.Parameters.Add("@idAula", SqlDbType.Int).Value = matricula.IdAula1
            Comando.Parameters.Add("@idusuario", SqlDbType.Int).Value = matricula.Idusuario1
            MyBase.MsConn1.Open()
            Comando.ExecuteNonQuery()
            MyBase.MsConn1.Close()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Function matriculadosporaulaD(matricula As Entidades.clsMatriculaE)
        Try
            Dim Resultado As SqlDataReader
            Dim Tabla As New DataTable
            Dim Comando As New SqlCommand("matriculadosporaula", MyBase.MsConn1)
            Comando.Parameters.Add("@idAula", SqlDbType.Int).Value = matricula.IdAula1
            Comando.CommandType = CommandType.StoredProcedure
            MyBase.MsConn1.Open()
            Resultado = Comando.ExecuteReader()
            Tabla.Load(Resultado)
            MyBase.MsConn1.Close()
            Return Tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Public Function matriculaycalificacionesxalumnoycursoD(matricula As Entidades.clsMatriculaE)
        Try
            Dim Resultado As SqlDataReader
            Dim Tabla As New DataTable
            Dim Comando As New SqlCommand("matriculaycalificacionesxalumnoycurso", MyBase.MsConn1)
            Comando.Parameters.Add("@idEstudiante", SqlDbType.Int).Value = matricula.IdEstudiante1
            Comando.Parameters.Add("@idAsignatura", SqlDbType.Int).Value = matricula.IdAsignatura1
            Comando.CommandType = CommandType.StoredProcedure
            MyBase.MsConn1.Open()
            Resultado = Comando.ExecuteReader()
            Tabla.Load(Resultado)
            MyBase.MsConn1.Close()
            Return Tabla
        Catch ex As Exception
            Throw ex
        End Try

    End Function

    Public Function ordenmeritoxcursoD(matricula As Entidades.clsMatriculaE)
        Try
            Dim Resultado As SqlDataReader
            Dim Tabla As New DataTable
            Dim Comando As New SqlCommand("ordenmeritoxcurso", MyBase.MsConn1)
            Comando.Parameters.Add("@idAsignatura", SqlDbType.Int).Value = matricula.IdAsignatura1
            Comando.CommandType = CommandType.StoredProcedure
            MyBase.MsConn1.Open()
            Resultado = Comando.ExecuteReader()
            Tabla.Load(Resultado)
            MyBase.MsConn1.Close()
            Return Tabla
        Catch ex As Exception
            Throw ex
        End Try

    End Function
    Public Function matriculadosporasignaturaD(matricula As Entidades.clsMatriculaE)
        Try
            Dim Resultado As SqlDataReader
            Dim Tabla As New DataTable
            Dim Comando As New SqlCommand("matriculadosporasignatura", MyBase.MsConn1)
            Comando.Parameters.Add("@idAsignatura", SqlDbType.Int).Value = matricula.IdAsignatura1
            Comando.CommandType = CommandType.StoredProcedure
            MyBase.MsConn1.Open()
            Resultado = Comando.ExecuteReader()
            Tabla.Load(Resultado)
            MyBase.MsConn1.Close()
            Return Tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function

End Class
