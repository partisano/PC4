﻿Imports System.Data.SqlClient
Imports Entidades
Public Class clstipoevaluacionD
    Inherits clsConexion
    Public Sub registrartipoevaluacionD(tipoevaluacion As Entidades.clstipoEvaluacionE)
        Try
            Dim Comando As New SqlCommand("registrartipoevaluacion", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            Comando.Parameters.Add("@Descripcion", SqlDbType.VarChar).Value = tipoevaluacion.Descripcion1
            MyBase.MsConn1.Open()
            Comando.ExecuteNonQuery()
            MyBase.MsConn1.Close()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Function listartipoevaluacionD() As DataTable
        Try
            Dim Resultado As SqlDataReader
            Dim Tabla As New DataTable
            Dim Comando As New SqlCommand("listartipoevaluacion", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            MyBase.MsConn1.Open()
            Resultado = Comando.ExecuteReader()
            Tabla.Load(Resultado)
            MyBase.MsConn1.Close()
            Return Tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
    Public Sub modificartipoevaluacionD(tipoevaluacion As Entidades.clstipoEvaluacionE)
        Try
            Dim Comando As New SqlCommand("modificartipoevaluacion", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            Comando.Parameters.Add("@idtipoevaluacion", SqlDbType.Int).Value = tipoevaluacion.Idtipoevaluacion1
            Comando.Parameters.Add("@Descripcion", SqlDbType.VarChar).Value = tipoevaluacion.Descripcion1
            MyBase.MsConn1.Open()
            Comando.ExecuteNonQuery()
            MyBase.MsConn1.Close()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Sub eliminartipoevaluacionD(tipoevaluacion As Entidades.clstipoEvaluacionE)
        Try
            Dim Comando As New SqlCommand("eliminartipoevaluacion", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            Comando.Parameters.Add("@idtipoevaluacion", SqlDbType.Int).Value = tipoevaluacion.Idtipoevaluacion1
            MyBase.MsConn1.Open()
            Comando.ExecuteNonQuery()
            MyBase.MsConn1.Close()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Function buscartipoevaluacionD(tipoevaluacion As Entidades.clstipoEvaluacionE) As DataTable
        Try
            Dim Resultado As SqlDataReader
            Dim Tabla As New DataTable
            Dim Comando As New SqlCommand("buscartipoevaluacion", MyBase.MsConn1)
            Comando.Parameters.Add("@parabuscar", SqlDbType.VarChar).Value = tipoevaluacion.Busqueda1
            Comando.CommandType = CommandType.StoredProcedure
            MyBase.MsConn1.Open()
            Resultado = Comando.ExecuteReader()
            Tabla.Load(Resultado)
            MyBase.MsConn1.Close()
            Return Tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
End Class
