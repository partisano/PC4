﻿Imports System.Data.SqlClient
Imports Entidades
Public Class clstipousuarioD
    Inherits clsConexion
    Public Function registrartipousuarioD(tipousuario As Entidades.clstipousuarioE) As Integer
        Try
            Dim Comando As New SqlCommand("registrartipousuario", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            Comando.Parameters.Add("@descripcion", SqlDbType.VarChar).Value = tipousuario.Descripcion1
            Comando.Parameters.Add("@tipousuario", SqlDbType.Int).Direction = ParameterDirection.Output
            Dim tipousuarioregistrado As Integer
            MyBase.MsConn1.Open()
            Comando.ExecuteNonQuery()
            tipousuarioregistrado = Comando.Parameters("@tipousuario").Value
            Return tipousuarioregistrado
            MyBase.MsConn1.Close()

        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Public Function listartipousuarioD() As DataTable
        Try
            Dim Resultado As SqlDataReader
            Dim Tabla As New DataTable
            Dim Comando As New SqlCommand("listartipousuario", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            MyBase.MsConn1.Open()
            Resultado = Comando.ExecuteReader()
            Tabla.Load(Resultado)
            MyBase.MsConn1.Close()
            Return Tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
    Public Sub modificartipousuarioD(tipousuario As Entidades.clstipousuarioE)
        Try
            Dim Comando As New SqlCommand("modificartipousuario", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            Comando.Parameters.Add("@idtipousuario", SqlDbType.Int).Value = tipousuario.Idtipousuario1
            Comando.Parameters.Add("@descripcion", SqlDbType.VarChar).Value = tipousuario.Descripcion1
            MyBase.MsConn1.Open()
            Comando.ExecuteNonQuery()
            MyBase.MsConn1.Close()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Sub eliminartipousuarioD(tipousuario As Entidades.clstipousuarioE)
        Try
            Dim Comando As New SqlCommand("eliminartipousuario", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            Comando.Parameters.Add("@idtipousuario", SqlDbType.Int).Value = tipousuario.Idtipousuario1
            MyBase.MsConn1.Open()
            Comando.ExecuteNonQuery()
            MyBase.MsConn1.Close()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Function buscartipousuarioD(tipousuario As Entidades.clstipousuarioE) As DataTable
        Try
            Dim Resultado As SqlDataReader
            Dim Tabla As New DataTable
            Dim Comando As New SqlCommand("buscartipousuario", MyBase.MsConn1)
            Comando.Parameters.Add("@parabuscar", SqlDbType.VarChar).Value = tipousuario.Busqueda1
            Comando.CommandType = CommandType.StoredProcedure
            MyBase.MsConn1.Open()
            Resultado = Comando.ExecuteReader()
            Tabla.Load(Resultado)
            MyBase.MsConn1.Close()
            Return Tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
End Class
