﻿Imports System.Data.SqlClient
Imports Entidades
Public Class clsusuarioD
    Inherits clsConexion
    Public Sub registrarusuarioD(usuario As Entidades.clsusuarioE)
        Try
            Dim Comando As New SqlCommand("registrarusuario", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            Comando.Parameters.Add("@usuario", SqlDbType.VarChar).Value = usuario.Usuario1
            Comando.Parameters.Add("@clave", SqlDbType.VarChar).Value = usuario.Clave1
            Comando.Parameters.Add("@idtipousuario", SqlDbType.Int).Value = usuario.Idtipousuario1
            MyBase.MsConn1.Open()
            Comando.ExecuteNonQuery()
            MyBase.MsConn1.Close()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Function listarusuarioD() As DataTable
        Try
            Dim Resultado As SqlDataReader
            Dim Tabla As New DataTable
            Dim Comando As New SqlCommand("listarusuario", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            MyBase.MsConn1.Open()
            Resultado = Comando.ExecuteReader()
            Tabla.Load(Resultado)
            MyBase.MsConn1.Close()
            Return Tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
    Public Sub modificarusuarioD(usuario As Entidades.clsusuarioE)
        Try
            Dim Comando As New SqlCommand("modificarusuario", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            Comando.Parameters.Add("@idusuario", SqlDbType.Int).Value = usuario.Idusuario1
            Comando.Parameters.Add("@usuario", SqlDbType.VarChar).Value = usuario.Usuario1
            Comando.Parameters.Add("@clave", SqlDbType.Int).Value = usuario.Clave1
            Comando.Parameters.Add("@idtipousuario", SqlDbType.Int).Value = usuario.Idtipousuario1
            MyBase.MsConn1.Open()
            Comando.ExecuteNonQuery()
            MyBase.MsConn1.Close()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Sub eliminarusuarioD(usuario As Entidades.clsusuarioE)
        Try
            Dim Comando As New SqlCommand("eliminarusuario", MyBase.MsConn1)
            Comando.CommandType = CommandType.StoredProcedure
            Comando.Parameters.Add("@Idusuario", SqlDbType.Int).Value = usuario.Idusuario1
            MyBase.MsConn1.Open()
            Comando.ExecuteNonQuery()
            MyBase.MsConn1.Close()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Function buscarusuarioD(usuario As Entidades.clsusuarioE) As DataTable
        Try
            Dim Resultado As SqlDataReader
            Dim Tabla As New DataTable
            Dim Comando As New SqlCommand("buscarusuario", MyBase.MsConn1)
            Comando.Parameters.Add("@parabuscar", SqlDbType.VarChar).Value = usuario.Busqueda1
            Comando.CommandType = CommandType.StoredProcedure
            MyBase.MsConn1.Open()
            Resultado = Comando.ExecuteReader()
            Tabla.Load(Resultado)
            MyBase.MsConn1.Close()
            Return Tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
    Public Function logueoD(usuario As Entidades.clsusuarioE) As DataTable
        Try
            Dim Resultado As SqlDataReader
            Dim Tabla As New DataTable
            Dim Comando As New SqlCommand("logueo", MyBase.MsConn1)
            Comando.Parameters.Add("@usuario", SqlDbType.VarChar).Value = usuario.Usuario1
            Comando.Parameters.Add("@clave", SqlDbType.VarChar).Value = usuario.Clave1
            Comando.CommandType = CommandType.StoredProcedure
            MyBase.MsConn1.Open()
            Resultado = Comando.ExecuteReader()
            Tabla.Load(Resultado)
            MyBase.MsConn1.Close()
            Return Tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
End Class
