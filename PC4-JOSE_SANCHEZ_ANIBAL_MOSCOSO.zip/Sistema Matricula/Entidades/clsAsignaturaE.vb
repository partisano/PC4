﻿Public Class clsAsignaturaE
    Private idAsignatura As Integer
    Private Nombre As String
    Private Creditos As Integer
    Private Tipo As String
    Private Ciclo As String
    Private busqueda As String

    Public Property IdAsignatura1 As Integer
        Get
            Return idAsignatura
        End Get
        Set(value As Integer)
            idAsignatura = value
        End Set
    End Property

    Public Property Nombre1 As String
        Get
            Return Nombre
        End Get
        Set(value As String)
            Nombre = value
        End Set
    End Property

    Public Property Creditos1 As Integer
        Get
            Return Creditos
        End Get
        Set(value As Integer)
            Creditos = value
        End Set
    End Property

    Public Property Tipo1 As String
        Get
            Return Tipo
        End Get
        Set(value As String)
            Tipo = value
        End Set
    End Property

    Public Property Ciclo1 As String
        Get
            Return Ciclo
        End Get
        Set(value As String)
            Ciclo = value
        End Set
    End Property

    Public Property Busqueda1 As String
        Get
            Return busqueda
        End Get
        Set(value As String)
            busqueda = value
        End Set
    End Property
End Class
