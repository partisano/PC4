﻿Public Class clsAulaE
    Private idAula As Integer
    Private Nombre As String
    Private Vacantes As Integer
    Private idGrupo As Integer
    Private busqueda As String
    Public Property IdAula1 As Integer
        Get
            Return idAula
        End Get
        Set(value As Integer)
            idAula = value
        End Set
    End Property

    Public Property Nombre1 As String
        Get
            Return Nombre
        End Get
        Set(value As String)
            Nombre = value
        End Set
    End Property

    Public Property Vacantes1 As Integer
        Get
            Return Vacantes
        End Get
        Set(value As Integer)
            Vacantes = value
        End Set
    End Property

    Public Property IdGrupo1 As Integer
        Get
            Return idGrupo
        End Get
        Set(value As Integer)
            idGrupo = value
        End Set
    End Property

    Public Property Busqueda1 As String
        Get
            Return busqueda
        End Get
        Set(value As String)
            busqueda = value
        End Set
    End Property
End Class
