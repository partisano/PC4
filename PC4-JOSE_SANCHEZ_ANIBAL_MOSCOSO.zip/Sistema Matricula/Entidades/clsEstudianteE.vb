﻿Public Class clsEstudianteE
    Private idEstudiante As Integer
    Private Nombres As String
    Private Apellidos As String
    Private Email As String
    Private Telefono As String
    Private FechaNac As Date
    Private Sexo As String
    Private Semestreingreso As String
    Private Busqueda As String

    Public Property IdEstudiante1 As Integer
        Get
            Return idEstudiante
        End Get
        Set(value As Integer)
            idEstudiante = value
        End Set
    End Property

    Public Property Nombres1 As String
        Get
            Return Nombres
        End Get
        Set(value As String)
            Nombres = value
        End Set
    End Property

    Public Property Apellidos1 As String
        Get
            Return Apellidos
        End Get
        Set(value As String)
            Apellidos = value
        End Set
    End Property

    Public Property Email1 As String
        Get
            Return Email
        End Get
        Set(value As String)
            Email = value
        End Set
    End Property

    Public Property Telefono1 As String
        Get
            Return Telefono
        End Get
        Set(value As String)
            Telefono = value
        End Set
    End Property

    Public Property FechaNac1 As Date
        Get
            Return FechaNac
        End Get
        Set(value As Date)
            FechaNac = value
        End Set
    End Property

    Public Property Sexo1 As String
        Get
            Return Sexo
        End Get
        Set(value As String)
            Sexo = value
        End Set
    End Property

    Public Property Semestreingreso1 As String
        Get
            Return Semestreingreso
        End Get
        Set(value As String)
            Semestreingreso = value
        End Set
    End Property

    Public Property Busqueda1 As String
        Get
            Return Busqueda
        End Get
        Set(value As String)
            Busqueda = value
        End Set
    End Property
End Class
