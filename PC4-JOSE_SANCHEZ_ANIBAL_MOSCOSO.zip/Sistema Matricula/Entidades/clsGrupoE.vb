﻿Public Class clsGrupoE
    Private idGrupo As Integer
    Private Letra As String
    Private busqueda As String

    Public Property IdGrupo1 As Integer
        Get
            Return idGrupo
        End Get
        Set(value As Integer)
            idGrupo = value
        End Set
    End Property

    Public Property Letra1 As String
        Get
            Return Letra
        End Get
        Set(value As String)
            Letra = value
        End Set
    End Property

    Public Property Busqueda1 As String
        Get
            Return busqueda
        End Get
        Set(value As String)
            busqueda = value
        End Set
    End Property
End Class
