﻿Public Class clsMatriculaE
    Private idMatricula As Integer
    Private Fechamatricula As Date
    Private idEstudiante As Integer
    Private idAsignatura As Integer
    Private idAula As Integer
    Private idusuario As Integer

    Public Property IdMatricula1 As Integer
        Get
            Return idMatricula
        End Get
        Set(value As Integer)
            idMatricula = value
        End Set
    End Property

    Public Property Fechamatricula1 As Date
        Get
            Return Fechamatricula
        End Get
        Set(value As Date)
            Fechamatricula = value
        End Set
    End Property

    Public Property IdEstudiante1 As Integer
        Get
            Return idEstudiante
        End Get
        Set(value As Integer)
            idEstudiante = value
        End Set
    End Property

    Public Property IdAsignatura1 As Integer
        Get
            Return idAsignatura
        End Get
        Set(value As Integer)
            idAsignatura = value
        End Set
    End Property

    Public Property IdAula1 As Integer
        Get
            Return idAula
        End Get
        Set(value As Integer)
            idAula = value
        End Set
    End Property

    Public Property Idusuario1 As Integer
        Get
            Return idusuario
        End Get
        Set(value As Integer)
            idusuario = value
        End Set
    End Property
End Class
