﻿Public Class clscalificacionE

    Private idcalificacion As Integer
    Private idmatricula As Integer
    Private idtipoevaluacion As Integer
    Private nota As Double

    Public Property Idcalificacion1 As Integer
        Get
            Return idcalificacion
        End Get
        Set(value As Integer)
            idcalificacion = value
        End Set
    End Property

    Public Property Idmatricula1 As Integer
        Get
            Return idmatricula
        End Get
        Set(value As Integer)
            idmatricula = value
        End Set
    End Property

    Public Property Idtipoevaluacion1 As Integer
        Get
            Return idtipoevaluacion
        End Get
        Set(value As Integer)
            idtipoevaluacion = value
        End Set
    End Property

    Public Property Nota1 As Double
        Get
            Return nota
        End Get
        Set(value As Double)
            nota = value
        End Set
    End Property
End Class
