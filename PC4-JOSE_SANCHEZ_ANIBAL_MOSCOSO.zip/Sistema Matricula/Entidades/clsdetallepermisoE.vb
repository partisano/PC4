﻿Public Class clsdetallepermisoE
    Private idelemento As Integer
    Private idtipousuario As Integer

    Public Property Idelemento1 As Integer
        Get
            Return idelemento
        End Get
        Set(value As Integer)
            idelemento = value
        End Set
    End Property

    Public Property Idtipousuario1 As Integer
        Get
            Return idtipousuario
        End Get
        Set(value As Integer)
            idtipousuario = value
        End Set
    End Property
End Class
