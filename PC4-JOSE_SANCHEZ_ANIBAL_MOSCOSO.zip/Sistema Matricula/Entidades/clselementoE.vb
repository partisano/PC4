﻿Public Class clselementoE
    Private idelemento As Integer
    Private descripcion As String
    Private busqueda As String

    Public Property Idelemento1 As Integer
        Get
            Return idelemento
        End Get
        Set(value As Integer)
            idelemento = value
        End Set
    End Property

    Public Property Descripcion1 As String
        Get
            Return descripcion
        End Get
        Set(value As String)
            descripcion = value
        End Set
    End Property

    Public Property Busqueda1 As String
        Get
            Return busqueda
        End Get
        Set(value As String)
            busqueda = value
        End Set
    End Property
End Class
