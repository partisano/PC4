﻿Public Class clstipoEvaluacionE
    Private idtipoevaluacion As Integer
    Private Descripcion As String
    Private busqueda As String
    Public Property Idtipoevaluacion1 As Integer
        Get
            Return idtipoevaluacion
        End Get
        Set(value As Integer)
            idtipoevaluacion = value
        End Set
    End Property
    Public Property Descripcion1 As String
        Get
            Return Descripcion
        End Get
        Set(value As String)
            Descripcion = value
        End Set
    End Property

    Public Property Busqueda1 As String
        Get
            Return busqueda
        End Get
        Set(value As String)
            busqueda = value
        End Set
    End Property
End Class
