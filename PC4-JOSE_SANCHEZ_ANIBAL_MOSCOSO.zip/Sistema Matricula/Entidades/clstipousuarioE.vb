﻿Public Class clstipousuarioE
    Private idtipousuario As Integer
    Private descripcion As String
    Private idpermiso As Integer
    Private busqueda As String

    Public Property Idtipousuario1 As Integer
        Get
            Return idtipousuario
        End Get
        Set(value As Integer)
            idtipousuario = value
        End Set
    End Property

    Public Property Descripcion1 As String
        Get
            Return descripcion
        End Get
        Set(value As String)
            descripcion = value
        End Set
    End Property

    Public Property Busqueda1 As String
        Get
            Return busqueda
        End Get
        Set(value As String)
            busqueda = value
        End Set
    End Property

    Public Property Idpermiso1 As Integer
        Get
            Return idpermiso
        End Get
        Set(value As Integer)
            idpermiso = value
        End Set
    End Property
End Class
