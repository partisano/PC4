﻿Public Class clsusuarioE
    Private idusuario As Integer
    Private usuario As String
    Private clave As String
    Private idtipousuario As Integer
    Private busqueda As String

    Public Property Idusuario1 As Integer
        Get
            Return idusuario
        End Get
        Set(value As Integer)
            idusuario = value
        End Set
    End Property

    Public Property Usuario1 As String
        Get
            Return usuario
        End Get
        Set(value As String)
            usuario = value
        End Set
    End Property

    Public Property Clave1 As String
        Get
            Return clave
        End Get
        Set(value As String)
            clave = value
        End Set
    End Property

    Public Property Idtipousuario1 As Integer
        Get
            Return idtipousuario
        End Get
        Set(value As Integer)
            idtipousuario = value
        End Set
    End Property

    Public Property Busqueda1 As String
        Get
            Return busqueda
        End Get
        Set(value As String)
            busqueda = value
        End Set
    End Property
End Class
