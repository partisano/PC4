﻿Imports Entidades
Imports Datos
Public Class clsAsignaturaN
    Public Sub registrarasignaturaN(asignaturaE As clsAsignaturaE)
        Try
            Dim asignaturaD As New clsAsignaturaD
            asignaturaD.registrarasignaturaD(asignaturaE)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Public Function listarasignaturaN() As DataTable
        Try
            Dim asignaturaD As New clsAsignaturaD
            Dim tabla As New DataTable
            tabla = asignaturaD.listarasignaturaD()
            Return tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Public Sub modificarasignaturaN(asignaturaE As clsAsignaturaE)
        Try
            Dim asignaturaD As New clsAsignaturaD
            asignaturaD.modificarasignaturaD(asignaturaE)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Sub eliminarasignaturaN(asignaturaE As clsAsignaturaE)
        Try
            Dim asignaturaD As New clsAsignaturaD
            asignaturaD.eliminarasignaturaD(asignaturaE)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Function buscarasignaturaN(asignaturaE As clsAsignaturaE) As DataTable
        Try
            Dim asignaturaD As New clsAsignaturaD
            Dim tabla As New DataTable
            tabla = asignaturaD.buscarasignaturaD(asignaturaE)
            Return tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
End Class
