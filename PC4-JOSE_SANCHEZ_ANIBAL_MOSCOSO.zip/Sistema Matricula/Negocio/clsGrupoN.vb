﻿Imports Entidades
Imports Datos

Public Class clsGrupoN
    Public Sub registrargrupoN(grupoE As clsGrupoE)
        Try
            Dim grupoD As New clsgrupoD
            grupoD.registrargrupoD(grupoE)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Public Function listargrupoN() As DataTable
        Try
            Dim grupoD As New clsgrupoD
            Dim tabla As New DataTable
            tabla = grupoD.listargrupoD()
            Return tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Public Sub modificargrupoN(grupoE As clsGrupoE)
        Try
            Dim grupoD As New clsgrupoD
            grupoD.modificargrupoD(grupoE)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Sub eliminargrupoN(grupoE As clsGrupoE)
        Try
            Dim grupoD As New clsgrupoD
            grupoD.eliminargrupoD(grupoE)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Function buscargrupoN(grupoE As clsGrupoE) As DataTable
        Try
            Dim grupoD As New clsgrupoD
            Dim tabla As New DataTable
            tabla = grupoD.buscargrupoD(grupoE)
            Return tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
End Class
