﻿Imports Entidades
Imports Datos
Public Class clsaulaN
    Public Sub registraraulaN(aulaE As clsAulaE)
        Try
            Dim aulaD As New clsaulaD
            aulaD.registraraulaD(aulaE)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Public Function listaraulaN() As DataTable
        Try
            Dim aulaD As New clsaulaD
            Dim tabla As New DataTable
            tabla = aulaD.listaraulaD()
            Return tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Public Sub modificaraulaN(aulaE As clsAulaE)
        Try
            Dim aulaD As New clsaulaD
            aulaD.modificaraulaD(aulaE)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Sub eliminaraulaN(aulaE As clsAulaE)
        Try
            Dim aulaD As New clsaulaD
            aulaD.eliminaraulaD(aulaE)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Function buscaraulaN(aulaE As clsAulaE) As DataTable
        Try
            Dim aulaD As New clsaulaD
            Dim tabla As New DataTable
            tabla = aulaD.buscaraulaD(aulaE)
            Return tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
End Class
