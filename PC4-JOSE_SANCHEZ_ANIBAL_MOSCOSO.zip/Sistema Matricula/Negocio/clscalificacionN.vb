﻿Imports Entidades
Imports Datos
Public Class clscalificacionN
    Public Sub registrarcalificacionN(calificacionE As clscalificacionE)
        Try
            Dim calificacionD As New clscalificacionD
            calificacionD.registrarcalificacionD(calificacionE)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
End Class
