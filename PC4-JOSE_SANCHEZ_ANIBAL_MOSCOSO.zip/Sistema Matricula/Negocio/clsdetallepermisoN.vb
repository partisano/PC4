﻿Imports Entidades
Imports Datos
Public Class clsdetallepermisoN
    Public Sub registrardetallepermisoN(detallepermisoE As clsdetallepermisoE)
        Try
            Dim detallepermisoD As New clsdetallepermisoD
            detallepermisoD.registrardetallepermisoD(detallepermisoE)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Public Function listardetallepermisoN() As DataTable
        Try
            Dim detallepermisoD As New clsdetallepermisoD
            Dim tabla As New DataTable
            tabla = detallepermisoD.listardetallepermisoD()
            Return tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Public Sub eliminardetallepermisoN(detallepermisoE As clsdetallepermisoE)
        Try
            Dim detallepermisoD As New clsdetallepermisoD
            detallepermisoD.eliminardetallepermisoD(detallepermisoE)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Function buscardetallepermisoN(detallepermisoE As clsdetallepermisoE) As DataTable
        Try
            Dim detallepermisoD As New clsdetallepermisoD
            Dim tabla As New DataTable
            tabla = detallepermisoD.buscardetallepermisoD(detallepermisoE)
            Return tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
End Class
