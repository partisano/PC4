﻿Imports Entidades
Imports Datos
Public Class clselementoN
    Public Sub registrarelementoN(elementoE As clselementoE)
        Try
            Dim elementoD As New clselementoD
            elementoD.registrarelementoD(elementoE)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Public Function listarelementoN() As DataTable
        Try
            Dim elementoD As New clselementoD
            Dim tabla As New DataTable
            tabla = elementoD.listarelementoD()
            Return tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Public Sub modificarelementoN(elementoE As clselementoE)
        Try
            Dim elementoD As New clselementoD
            elementoD.modificarelementoD(elementoE)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Sub eliminarelementoN(elementoE As clselementoE)
        Try
            Dim elementoD As New clselementoD
            elementoD.eliminarelementoD(elementoE)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Function buscarelementoN(elementoE As clselementoE) As DataTable
        Try
            Dim elementoD As New clselementoD
            Dim tabla As New DataTable
            tabla = elementoD.buscarelementoD(elementoE)
            Return tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
End Class
