﻿Imports Entidades
Imports Datos
Public Class clsestudianteN
    Public Sub registrarestudianteN(estudianteE As clsEstudianteE)
        Try
            Dim estudianteD As New clsestudianteD
            estudianteD.registrarestudianteD(estudianteE)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Public Function listarestudianteN() As DataTable
        Try
            Dim estudianteD As New clsestudianteD
            Dim tabla As New DataTable
            tabla = estudianteD.listarestudianteD()
            Return tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Public Sub modificarestudianteN(estudianteE As clsEstudianteE)
        Try
            Dim estudianteD As New clsestudianteD
            estudianteD.modificarestudianteD(estudianteE)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Sub eliminarestudianteN(estudianteE As clsEstudianteE)
        Try
            Dim estudianteD As New clsestudianteD
            estudianteD.eliminarestudianteD(estudianteE)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Function buscarestudianteN(estudianteE As clsEstudianteE) As DataTable
        Try
            Dim estudianteD As New clsestudianteD
            Dim tabla As New DataTable
            tabla = estudianteD.buscarestudianteD(estudianteE)
            Return tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
End Class
