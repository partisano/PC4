﻿Imports Entidades
Imports Datos
Public Class clsmatriculaN
    Public Sub registrarmatriculaN(matriculaE As clsMatriculaE)
        Try
            Dim matriculaD As New clsmatriculaD
            matriculaD.registrarmatriculaD(matriculaE)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Public Function matriculadosporaulaN(matriculaE As clsMatriculaE) As DataTable
        Try
            Dim matriculaD As New clsmatriculaD
            Dim tabla As New DataTable
            tabla = matriculaD.matriculadosporaulaD(matriculaE)
            Return tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
    Public Function matriculaycalificacionesxalumnoycursoN(matriculaE As clsMatriculaE) As DataTable
        Try
            Dim matriculaD As New clsmatriculaD
            Dim tabla As New DataTable
            tabla = matriculaD.matriculaycalificacionesxalumnoycursoD(matriculaE)
            Return tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
    Public Function ordenmeritoxcursoN(matriculaE As clsMatriculaE) As DataTable
        Try
            Dim matriculaD As New clsmatriculaD
            Dim tabla As New DataTable
            tabla = matriculaD.ordenmeritoxcursoD(matriculaE)
            Return tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
    Public Function matriculadosporasignaturaN(matriculaE As clsMatriculaE) As DataTable
        Try
            Dim matriculaD As New clsmatriculaD
            Dim tabla As New DataTable
            tabla = matriculaD.matriculadosporasignaturaD(matriculaE)
            Return tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
End Class
