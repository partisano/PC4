﻿Imports Entidades
Imports Datos
Public Class clstipoevaluacionN
    Public Sub registrartipoevaluacionN(tipoevaluacionE As clstipoEvaluacionE)
        Try
            Dim tipoevaluacionD As New clstipoevaluacionD
            tipoevaluacionD.registrartipoevaluacionD(tipoevaluacionE)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Public Function listartipoevaluacionN() As DataTable
        Try
            Dim tipoevaluacionD As New clstipoevaluacionD
            Dim tabla As New DataTable
            tabla = tipoevaluacionD.listartipoevaluacionD()
            Return tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Public Sub modificartipoevaluacionN(tipoevaluacionE As clstipoEvaluacionE)
        Try
            Dim tipoevaluacionD As New clstipoevaluacionD
            tipoevaluacionD.modificartipoevaluacionD(tipoevaluacionE)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Sub eliminartipoevaluacionN(tipoevaluacionE As clstipoEvaluacionE)
        Try
            Dim tipoevaluacionD As New clstipoevaluacionD
            tipoevaluacionD.eliminartipoevaluacionD(tipoevaluacionE)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Function buscartipoevaluacionN(tipoevaluacionE As clstipoEvaluacionE) As DataTable
        Try
            Dim tipoevaluacionD As New clstipoevaluacionD
            Dim tabla As New DataTable
            tabla = tipoevaluacionD.buscartipoevaluacionD(tipoevaluacionE)
            Return tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
End Class
