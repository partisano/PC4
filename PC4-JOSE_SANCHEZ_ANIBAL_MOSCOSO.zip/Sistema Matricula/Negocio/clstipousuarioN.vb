﻿Imports Entidades
Imports Datos
Public Class clstipousuarioN
    Public Function registrartipousuarioN(tipousuarioE As clstipousuarioE) As Integer
        Try
            Dim tipousuarioD As New clstipousuarioD

            Dim tipousuariore As Integer
            tipousuariore = tipousuarioD.registrartipousuarioD(tipousuarioE)
            Return tipousuariore
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Public Function listartipousuarioN() As DataTable
        Try
            Dim tipousuarioD As New clstipousuarioD
            Dim tabla As New DataTable
            tabla = tipousuarioD.listartipousuarioD()
            Return tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
    Public Sub modificartipousuarioN(tipousuarioE As clstipousuarioE)
        Try
            Dim tipousuarioD As New clstipousuarioD
            tipousuarioD.modificartipousuarioD(tipousuarioE)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Sub eliminartipousuarioN(tipousuarioE As clstipousuarioE)
        Try
            Dim tipousuarioD As New clstipousuarioD
            tipousuarioD.eliminartipousuarioD(tipousuarioE)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Function buscartipousuarioN(tipousuarioE As clstipousuarioE) As DataTable
        Try
            Dim tipousuarioD As New clstipousuarioD
            Dim tabla As New DataTable
            tabla = tipousuarioD.buscartipousuarioD(tipousuarioE)
            Return tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
End Class
