﻿Imports Entidades
Imports Datos
Public Class clsusuarioN
    Public Sub registrarusuarioN(usuarioE As clsusuarioE)
        Try
            Dim usuarioD As New clsusuarioD
            usuarioD.registrarusuarioD(usuarioE)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Public Function listarusuarioN() As DataTable
        Try
            Dim usuarioD As New clsusuarioD
            Dim tabla As New DataTable
            tabla = usuarioD.listarusuarioD()
            Return tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Public Sub modificarusuarioN(usuarioE As clsusuarioE)
        Try
            Dim usuarioD As New clsusuarioD
            usuarioD.modificarusuarioD(usuarioE)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Sub eliminarusuarioN(usuarioE As clsusuarioE)
        Try
            Dim usuarioD As New clsusuarioD
            usuarioD.eliminarusuarioD(usuarioE)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Function buscarusuarioN(usuarioE As clsusuarioE) As DataTable
        Try
            Dim usuarioD As New clsusuarioD
            Dim tabla As New DataTable
            tabla = usuarioD.buscarusuarioD(usuarioE)
            Return tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
    Public Function logueoN(usuarioE As clsusuarioE) As DataTable
        Try
            Dim usuarioD As New clsusuarioD
            Dim tabla As New DataTable
            tabla = usuarioD.logueoD(usuarioE)
            Return tabla
        Catch ex As Exception
            Throw ex
        End Try
    End Function
End Class
