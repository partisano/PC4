﻿Imports Entidades
Imports Negocio
Public Class frmAsignatura
    Dim asignaturaN As New clsAsignaturaN
    Dim asignaturaE As New clsAsignaturaE
    Private Sub btnregistrar_Click(sender As Object, e As EventArgs) Handles btnregistrar.Click

        If txtcodigo.Text.Trim <> String.Empty Then
            MsgBox("Debe limpiar el código")
            btnLimpiar.Focus()
            Exit Sub
        End If

        If txtnombre.Text.Trim = String.Empty Then
            MsgBox("Ingrese nombre de asignatura")
            txtnombre.Focus()
            Exit Sub
        End If

        If nudcreditos.Value.ToString = String.Empty Or nudcreditos.Value = 0 Then
            MsgBox("Número de créditos debe ser mayor a 0")
            nudcreditos.Focus()
            Exit Sub
        End If

        asignaturaE.Nombre1 = txtnombre.Text
        asignaturaE.Creditos1 = nudcreditos.Value
        asignaturaE.Tipo1 = cbxTipoasignatura.Text
        asignaturaE.Ciclo1 = cbxCiclo.Text
        asignaturaN.registrarasignaturaN(asignaturaE)
        MsgBox("Registro OK")
        dtgdatos.DataSource = asignaturaN.listarasignaturaN()
        txtnombre.Clear()
        nudcreditos.Value = 0
        cbxTipoasignatura.SelectedIndex = 0
        cbxCiclo.SelectedIndex = 0
    End Sub

    Private Sub frmAsignatura_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim encontro As Boolean = False
        For index = 0 To frmlogin.permisos.Count - 1
            If frmlogin.permisos(index).ToString = "frmAsignatura" Then
                encontro = True
            End If
        Next
        If encontro <> True Then
            Close()
        End If

        cbxTipoasignatura.SelectedIndex = 0
        cbxCiclo.SelectedIndex = 0
        dtgdatos.DataSource = asignaturaN.listarasignaturaN()
    End Sub

    Private Sub btnmodificar_Click(sender As Object, e As EventArgs) Handles btnmodificar.Click
        If txtcodigo.Text.Trim = String.Empty Then
            MsgBox("Seleccione elemento de la lista")
            dtgdatos.Focus()
            Exit Sub
        End If
        If txtnombre.Text.Trim = String.Empty Then
            MsgBox("Ingrese nombre de la asignatura")
            txtnombre.Focus()
            Exit Sub
        End If

        If nudcreditos.Value.ToString = String.Empty Or nudcreditos.Value = 0 Then
            MsgBox("Número de créditos debe ser mayor a 0")
            nudcreditos.Focus()
            Exit Sub
        End If
        asignaturaE.IdAsignatura1 = txtcodigo.Text
        asignaturaE.Nombre1 = txtnombre.Text
        asignaturaE.Creditos1 = nudcreditos.Value
        asignaturaE.Tipo1 = cbxTipoasignatura.Text
        asignaturaE.Ciclo1 = cbxCiclo.Text
        asignaturaN.modificarasignaturaN(asignaturaE)
        MsgBox("Modificado OK")
        dtgdatos.DataSource = asignaturaN.listarasignaturaN()
        txtcodigo.Clear()
        txtnombre.Clear()
        nudcreditos.Value = 0
        cbxTipoasignatura.SelectedIndex = 0
        cbxCiclo.SelectedIndex = 0

    End Sub

    Private Sub btneliminar_Click(sender As Object, e As EventArgs) Handles btneliminar.Click

        If txtcodigo.Text.Trim = String.Empty Then
            MsgBox("Seleccione elemento de la lista")
            dtgdatos.Focus()
            Exit Sub
        End If
        asignaturaE.IdAsignatura1 = txtcodigo.Text
        asignaturaN.eliminarasignaturaN(asignaturaE)
        MsgBox("ELiminado OK")
        dtgdatos.DataSource = asignaturaN.listarasignaturaN()
        txtcodigo.Clear()
        txtnombre.Clear()
        nudcreditos.Value = 0
        cbxTipoasignatura.SelectedIndex = 0
        cbxCiclo.SelectedIndex = 0

    End Sub

    Private Sub btnLimpiar_Click(sender As Object, e As EventArgs) Handles btnLimpiar.Click
        txtcodigo.Clear()
        txtnombre.Clear()
        nudcreditos.Value = 0
        cbxTipoasignatura.SelectedIndex = 0
        cbxCiclo.SelectedIndex = 0
    End Sub

    Private Sub btnbuscar_Click(sender As Object, e As EventArgs) Handles btnbuscar.Click
        If txtbusqueda.Text.Trim = String.Empty Then
            dtgdatos.DataSource = asignaturaN.listarasignaturaN()
        Else
            asignaturaE.Busqueda1 = txtbusqueda.Text.Trim
            dtgdatos.DataSource = asignaturaN.buscarasignaturaN(asignaturaE)
        End If
    End Sub

    Private Sub dtgdatos_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dtgdatos.CellClick
        txtcodigo.Text = dtgdatos.Rows(e.RowIndex).Cells(0).Value 'Caputar el id de la persona seleccionada
        txtnombre.Text = dtgdatos.Rows(e.RowIndex).Cells(1).Value
        nudcreditos.Value = dtgdatos.Rows(e.RowIndex).Cells(2).Value
        cbxTipoasignatura.Text = dtgdatos.Rows(e.RowIndex).Cells(3).Value
        cbxCiclo.Text = dtgdatos.Rows(e.RowIndex).Cells(4).Value

    End Sub
End Class