﻿Imports Negocio
Imports Entidades
Public Class frmAula
    Dim objetogrupo As New clsGrupoN
    Dim aulaE As New clsAulaE
    Dim aulaN As New clsaulaN
    Private Sub frmAula_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim encontro As Boolean = False
        For index = 0 To frmlogin.permisos.Count - 1
            If frmlogin.permisos(index).ToString = "frmAula" Then
                encontro = True
            End If
        Next
        If encontro <> True Then
            Close()
        End If
        llenarcombogrupo()
        dtgdatos.DataSource = aulaN.listaraulaN()
    End Sub

    Sub llenarcombogrupo()
        cbxgrupo.DisplayMember = "Letra"
        cbxgrupo.ValueMember = "idGrupo"
        cbxgrupo.DataSource = objetogrupo.listargrupoN
    End Sub

    Private Sub btnregistrar_Click(sender As Object, e As EventArgs) Handles btnregistrar.Click
        If txtcodigo.Text.Trim <> String.Empty Then
            MsgBox("Debe limpiar el código")
            btnLimpiar.Focus()
            Exit Sub
        End If

        If txtnombre.Text.Trim = String.Empty Then
            MsgBox("Ingrese nombre de aula")
            txtnombre.Focus()
            Exit Sub
        End If
        If nudvacantes.Value.ToString = String.Empty Or nudvacantes.Value = 0 Then
            MsgBox("Vacantes debe ser mayor a 0")
            nudvacantes.Focus()
            Exit Sub
        End If

        aulaE.Nombre1 = txtnombre.Text
        aulaE.Vacantes1 = nudvacantes.Value
        aulaE.IdGrupo1 = cbxgrupo.SelectedValue
        aulaN.registraraulaN(aulaE)
        MsgBox("Registro OK")
        dtgdatos.DataSource = aulaN.listaraulaN()
        txtnombre.Clear()
        nudvacantes.Value = 0

    End Sub

    Private Sub dtgdatos_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dtgdatos.CellClick
        txtcodigo.Text = dtgdatos.Rows(e.RowIndex).Cells(0).Value 'Caputar el id de la persona seleccionada
        txtnombre.Text = dtgdatos.Rows(e.RowIndex).Cells(1).Value
        nudvacantes.Value = dtgdatos.Rows(e.RowIndex).Cells(2).Value
        cbxgrupo.Text = dtgdatos.Rows(e.RowIndex).Cells(3).Value
    End Sub

    Private Sub btnLimpiar_Click(sender As Object, e As EventArgs) Handles btnLimpiar.Click
        txtcodigo.Clear()
        txtnombre.Clear()
        nudvacantes.Value = 0
    End Sub

    Private Sub btnmodificar_Click(sender As Object, e As EventArgs) Handles btnmodificar.Click
        If txtcodigo.Text.Trim = String.Empty Then
            MsgBox("Seleccione elemento de la lista")
            dtgdatos.Focus()
            Exit Sub
        End If
        If txtnombre.Text.Trim = String.Empty Then
            MsgBox("Ingrese nombre de aula")
            txtnombre.Focus()
            Exit Sub
        End If
        If nudvacantes.Value.ToString = String.Empty Or nudvacantes.Value = 0 Then
            MsgBox("Nº de vacantes debe ser mayor a 0")
            nudvacantes.Focus()
            Exit Sub
        End If
        aulaE.IdAula1 = txtcodigo.Text
        aulaE.Nombre1 = txtnombre.Text
        aulaE.Vacantes1 = nudvacantes.Value
        aulaE.IdGrupo1 = cbxgrupo.SelectedValue
        aulaN.modificaraulaN(aulaE)
        MsgBox("Modificado OK")
        dtgdatos.DataSource = aulaN.listaraulaN()
        txtcodigo.Clear()
        txtnombre.Clear()
        nudvacantes.Value = 0
    End Sub

    Private Sub btneliminar_Click(sender As Object, e As EventArgs) Handles btneliminar.Click
        If txtcodigo.Text.Trim = String.Empty Then
            MsgBox("Seleccione elemento de la lista")
            dtgdatos.Focus()
            Exit Sub
        End If
        aulaE.IdAula1 = txtcodigo.Text
        aulaN.eliminaraulaN(aulaE)
        MsgBox("ELiminado OK")
        dtgdatos.DataSource = aulaN.listaraulaN()
        txtcodigo.Clear()
        txtnombre.Clear()
        nudvacantes.Value = 0
    End Sub

    Private Sub btnbuscar_Click(sender As Object, e As EventArgs) Handles btnbuscar.Click
        If txtbusqueda.Text.Trim = String.Empty Then
            dtgdatos.DataSource = aulaN.listaraulaN()
        Else
            aulaE.Busqueda1 = txtbusqueda.Text.Trim
            dtgdatos.DataSource = aulaN.buscaraulaN(aulaE)
        End If
    End Sub
End Class