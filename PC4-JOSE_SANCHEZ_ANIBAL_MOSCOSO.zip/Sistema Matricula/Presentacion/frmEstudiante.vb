﻿Imports Entidades
Imports Negocio
Public Class frmEstudiante
    Dim estudianteN As New clsestudianteN
    Dim estudianteE As New clsEstudianteE
    Private Sub btnregistrar_Click(sender As Object, e As EventArgs) Handles btnregistrar.Click
        If txtcodigo.Text.Trim <> String.Empty Then
            MsgBox("Debe limpiar el código")
            btnLimpiar.Focus()
            Exit Sub
        End If

        If txtnombres.Text.Trim = String.Empty Then
            MsgBox("Ingrese nombres del estudiante")
            txtnombres.Focus()
            Exit Sub
        End If

        If txtapellidos.Text.Trim = String.Empty Then
            MsgBox("Ingrese apellidos del estudiante")
            txtapellidos.Focus()
            Exit Sub
        End If

        If txtemail.Text.Trim = String.Empty Then
            MsgBox("Ingrese correo electrónico del estudiante")
            txtemail.Focus()
            Exit Sub
        End If

        If txtTelefono.Text.Trim = String.Empty Then
            MsgBox("Ingrese número de teléfoco o celular del estudiante")
            txtTelefono.Focus()
            Exit Sub
        End If
        If txtsemestreingreso.Text.Trim = String.Empty Then
            MsgBox("Ingrese semestre que ingresó el estudiante")
            txtsemestreingreso.Focus()
            Exit Sub
        End If

        estudianteE.Nombres1 = txtnombres.Text
        estudianteE.Apellidos1 = txtapellidos.Text
        estudianteE.Email1 = txtemail.Text
        estudianteE.Telefono1 = txtTelefono.Text
        estudianteE.FechaNac1 = dtpfecnac.Value
        Dim sexo As String
        If rbtmasculino.Checked = True Then
            sexo = "M"
        Else
            sexo = "F"
        End If
        estudianteE.Sexo1 = sexo
        estudianteE.Semestreingreso1 = txtsemestreingreso.Text
        estudianteN.registrarestudianteN(estudianteE)
        MsgBox("Registro OK")
        dtgdatos.DataSource = estudianteN.listarestudianteN()
        txtnombres.Clear()
        txtapellidos.Clear()
        txtemail.Clear()
        txtTelefono.Clear()

        txtsemestreingreso.Clear()

    End Sub

    Private Sub btnmodificar_Click(sender As Object, e As EventArgs) Handles btnmodificar.Click
        If txtcodigo.Text.Trim = String.Empty Then
            MsgBox("Seleccione elemento de la lista")
            dtgdatos.Focus()
            Exit Sub
        End If

        If txtnombres.Text.Trim = String.Empty Then
            MsgBox("Ingrese nombres del estudiante")
            txtnombres.Focus()
            Exit Sub
        End If

        If txtapellidos.Text.Trim = String.Empty Then
            MsgBox("Ingrese apellidos del estudiante")
            txtapellidos.Focus()
            Exit Sub
        End If

        If txtemail.Text.Trim = String.Empty Then
            MsgBox("Ingrese correo electrónico del estudiante")
            txtemail.Focus()
            Exit Sub
        End If

        If txtTelefono.Text.Trim = String.Empty Then
            MsgBox("Ingrese número de teléfoco o celular del estudiante")
            txtTelefono.Focus()
            Exit Sub
        End If

        estudianteE.IdEstudiante1 = txtcodigo.Text
        estudianteE.Nombres1 = txtnombres.Text
        estudianteE.Apellidos1 = txtapellidos.Text
        estudianteE.Email1 = txtemail.Text
        estudianteE.Telefono1 = txtTelefono.Text
        estudianteE.FechaNac1 = dtpfecnac.Value
        Dim sexo As String
        If rbtmasculino.Checked = True Then
            sexo = "M"
        Else
            sexo = "F"
        End If
        estudianteE.Sexo1 = sexo
        estudianteE.Semestreingreso1 = txtsemestreingreso.Text
        estudianteN.modificarestudianteN(estudianteE)
        MsgBox("Modificado OK")
        dtgdatos.DataSource = estudianteN.listarestudianteN()
        txtcodigo.Clear()
        txtnombres.Clear()
        txtapellidos.Clear()
        txtemail.Clear()
        txtTelefono.Clear()

        txtsemestreingreso.Clear()


    End Sub

    Private Sub btneliminar_Click(sender As Object, e As EventArgs) Handles btneliminar.Click
        If txtcodigo.Text.Trim = String.Empty Then
            MsgBox("Seleccione elemento de la lista")
            dtgdatos.Focus()
            Exit Sub
        End If
        estudianteE.IdEstudiante1 = txtcodigo.Text
        estudianteN.eliminarestudianteN(estudianteE)
        MsgBox("ELiminado OK")
        dtgdatos.DataSource = estudianteN.listarestudianteN()
        txtcodigo.Clear()
        txtnombres.Clear()
        txtapellidos.Clear()
        txtemail.Clear()
        txtTelefono.Clear()

        txtsemestreingreso.Clear()

    End Sub

    Private Sub btnLimpiar_Click(sender As Object, e As EventArgs) Handles btnLimpiar.Click
        txtcodigo.Clear()
        txtnombres.Clear()
        txtapellidos.Clear()
        txtemail.Clear()
        txtTelefono.Clear()

        txtsemestreingreso.Clear()
    End Sub

    Private Sub btnbuscar_Click(sender As Object, e As EventArgs) Handles btnbuscar.Click
        If txtbusqueda.Text.Trim = String.Empty Then
            dtgdatos.DataSource = estudianteN.listarestudianteN()
        Else
            estudianteE.Busqueda1 = txtbusqueda.Text.Trim
            dtgdatos.DataSource = estudianteN.buscarestudianteN(estudianteE)
        End If

    End Sub


    Private Sub dtgdatos_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dtgdatos.CellClick
        txtcodigo.Text = dtgdatos.Rows(e.RowIndex).Cells(0).Value 'Caputar el id de la persona seleccionada
        txtnombres.Text = dtgdatos.Rows(e.RowIndex).Cells(1).Value
        txtapellidos.Text = dtgdatos.Rows(e.RowIndex).Cells(2).Value
        txtemail.Text = dtgdatos.Rows(e.RowIndex).Cells(3).Value
        txtTelefono.Text = dtgdatos.Rows(e.RowIndex).Cells(4).Value
        dtpfecnac.Value = dtgdatos.Rows(e.RowIndex).Cells(5).Value
        If dtgdatos.Rows(e.RowIndex).Cells(6).Value = "M" Then
            rbtmasculino.Checked = True
        Else
            rbtfemenino.Checked = True
        End If
        txtsemestreingreso.Text = dtgdatos.Rows(e.RowIndex).Cells(7).Value
    End Sub

    Private Sub txtbusqueda_TextChanged(sender As Object, e As EventArgs) Handles txtbusqueda.TextChanged

    End Sub

    Private Sub frmEstudiante_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim encontro As Boolean = False
        For index = 0 To frmlogin.permisos.Count - 1
            If frmlogin.permisos(index).ToString = "frmEstudiante" Then
                encontro = True
            End If
        Next
        If encontro <> True Then
            Close()
        End If
    End Sub
End Class
