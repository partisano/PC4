﻿Imports Negocio
Imports Entidades
Public Class frmGrupo
    Dim grupoN As New clsGrupoN
    Dim grupoE As New clsGrupoE
    Private Sub btnregistrar_Click(sender As Object, e As EventArgs) Handles btnregistrar.Click
        If txtcodigo.Text.Trim <> String.Empty Then
            MsgBox("Debe limpiar el código")
            btnLimpiar.Focus()
            Exit Sub
        End If

        If txtletra.Text.Trim = String.Empty Then
            MsgBox("Ingrese letra de grupo")
            txtletra.Focus()
            Exit Sub
        End If


        grupoE.Letra1 = txtletra.Text
        grupoN.registrargrupoN(grupoE)
        MsgBox("Registro OK")
        dtggrupo.DataSource = grupoN.listargrupoN()
        txtletra.Clear()
    End Sub

    Private Sub frmGrupo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim encontro As Boolean = False
        For index = 0 To frmlogin.permisos.Count - 1
            If frmlogin.permisos(index).ToString = "frmGrupo" Then
                encontro = True
            End If
        Next
        If encontro <> True Then
            Close()
        End If
        dtggrupo.DataSource = grupoN.listargrupoN()
    End Sub

    Private Sub dtggrupo_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dtggrupo.CellClick

        txtcodigo.Text = dtggrupo.Rows(e.RowIndex).Cells(0).Value 'Caputar el id de la persona seleccionada
        txtletra.Text = dtggrupo.Rows(e.RowIndex).Cells(1).Value
    End Sub


    Private Sub btnmodificar_Click(sender As Object, e As EventArgs) Handles btnmodificar.Click
        If txtcodigo.Text.Trim = String.Empty Then
            MsgBox("Seleccione elemento de la lista")
            dtggrupo.Focus()
            Exit Sub
        End If
        If txtletra.Text.Trim = String.Empty Then
            MsgBox("Ingrese letra de grupo")
            txtletra.Focus()
            Exit Sub
        End If

        grupoE.IdGrupo1 = txtcodigo.Text
        grupoE.Letra1 = txtletra.Text
        grupoN.modificargrupoN(grupoE)
        MsgBox("Modificado OK")
        dtggrupo.DataSource = grupoN.listargrupoN()
        txtcodigo.Clear()
        txtletra.Clear()
    End Sub

    Private Sub btneliminar_Click(sender As Object, e As EventArgs) Handles btneliminar.Click
        If txtcodigo.Text.Trim = String.Empty Then
            MsgBox("Seleccione elemento de la lista")
            dtggrupo.Focus()
            Exit Sub
        End If
        grupoE.IdGrupo1 = txtcodigo.Text
        grupoN.eliminargrupoN(grupoE)
        MsgBox("Eliminado OK")
        dtggrupo.DataSource = grupoN.listargrupoN()
        txtcodigo.Clear()
        txtletra.Clear()
    End Sub

    Private Sub btnbuscar_Click(sender As Object, e As EventArgs) Handles btnbuscar.Click
        If txtbusqueda.Text.Trim = String.Empty Then
            dtggrupo.DataSource = grupoN.listargrupoN()
        Else
            grupoE.Busqueda1 = txtbusqueda.Text.Trim
            dtggrupo.DataSource = grupoN.buscargrupoN(grupoE)
        End If

    End Sub

    Private Sub btnLimpiar_Click(sender As Object, e As EventArgs) Handles btnLimpiar.Click
        txtcodigo.Clear()
        Me.txtletra.Clear()

    End Sub
End Class