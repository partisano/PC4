﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMatricula
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dtpfechamatricula = New System.Windows.Forms.DateTimePicker()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnnuevo = New System.Windows.Forms.Button()
        Me.btnbuscar = New System.Windows.Forms.Button()
        Me.txtbusqueda = New System.Windows.Forms.TextBox()
        Me.txtapellidos = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtcodigo = New System.Windows.Forms.TextBox()
        Me.txtnombres = New System.Windows.Forms.TextBox()
        Me.dtgestudiante = New System.Windows.Forms.DataGridView()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtaciclo = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtacreditos = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.btnnuevaasignatura = New System.Windows.Forms.Button()
        Me.btnbuscarasignatura = New System.Windows.Forms.Button()
        Me.txtbusquedaasignatura = New System.Windows.Forms.TextBox()
        Me.txtatipo = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtacodigo = New System.Windows.Forms.TextBox()
        Me.txtanombre = New System.Windows.Forms.TextBox()
        Me.dtgasignatura = New System.Windows.Forms.DataGridView()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.txtgrupoaula = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.btnnuevaaula = New System.Windows.Forms.Button()
        Me.btnbuscaraula = New System.Windows.Forms.Button()
        Me.txtbusquedaaula = New System.Windows.Forms.TextBox()
        Me.txtvacantesaula = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtcodigoaula = New System.Windows.Forms.TextBox()
        Me.txtnombreaula = New System.Windows.Forms.TextBox()
        Me.dtgaula = New System.Windows.Forms.DataGridView()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.btnmatricular = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        CType(Me.dtgestudiante, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.dtgasignatura, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        CType(Me.dtgaula, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(279, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(77, 13)
        Me.Label1.TabIndex = 85
        Me.Label1.Text = "MATRICULAR"
        '
        'dtpfechamatricula
        '
        Me.dtpfechamatricula.Location = New System.Drawing.Point(72, 33)
        Me.dtpfechamatricula.Name = "dtpfechamatricula"
        Me.dtpfechamatricula.Size = New System.Drawing.Size(200, 20)
        Me.dtpfechamatricula.TabIndex = 86
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(25, 36)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(40, 13)
        Me.Label2.TabIndex = 87
        Me.Label2.Text = "Fecha:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnnuevo)
        Me.GroupBox1.Controls.Add(Me.btnbuscar)
        Me.GroupBox1.Controls.Add(Me.txtbusqueda)
        Me.GroupBox1.Controls.Add(Me.txtapellidos)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.txtcodigo)
        Me.GroupBox1.Controls.Add(Me.txtnombres)
        Me.GroupBox1.Controls.Add(Me.dtgestudiante)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Location = New System.Drawing.Point(28, 59)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(580, 108)
        Me.GroupBox1.TabIndex = 88
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Estudiante:"
        '
        'btnnuevo
        '
        Me.btnnuevo.Location = New System.Drawing.Point(233, 14)
        Me.btnnuevo.Name = "btnnuevo"
        Me.btnnuevo.Size = New System.Drawing.Size(51, 23)
        Me.btnnuevo.TabIndex = 89
        Me.btnnuevo.Text = "Nuevo"
        Me.btnnuevo.UseVisualStyleBackColor = True
        '
        'btnbuscar
        '
        Me.btnbuscar.Location = New System.Drawing.Point(168, 14)
        Me.btnbuscar.Name = "btnbuscar"
        Me.btnbuscar.Size = New System.Drawing.Size(59, 23)
        Me.btnbuscar.TabIndex = 96
        Me.btnbuscar.Text = "&Buscar"
        Me.btnbuscar.UseVisualStyleBackColor = True
        '
        'txtbusqueda
        '
        Me.txtbusqueda.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtbusqueda.Location = New System.Drawing.Point(6, 14)
        Me.txtbusqueda.Name = "txtbusqueda"
        Me.txtbusqueda.Size = New System.Drawing.Size(156, 20)
        Me.txtbusqueda.TabIndex = 95
        '
        'txtapellidos
        '
        Me.txtapellidos.Location = New System.Drawing.Point(55, 83)
        Me.txtapellidos.MaxLength = 30
        Me.txtapellidos.Name = "txtapellidos"
        Me.txtapellidos.ReadOnly = True
        Me.txtapellidos.Size = New System.Drawing.Size(189, 20)
        Me.txtapellidos.TabIndex = 91
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 42)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(43, 13)
        Me.Label3.TabIndex = 88
        Me.Label3.Text = "Código:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(6, 86)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(52, 13)
        Me.Label7.TabIndex = 94
        Me.Label7.Text = "Apellidos:"
        '
        'txtcodigo
        '
        Me.txtcodigo.Location = New System.Drawing.Point(55, 37)
        Me.txtcodigo.Name = "txtcodigo"
        Me.txtcodigo.ReadOnly = True
        Me.txtcodigo.Size = New System.Drawing.Size(57, 20)
        Me.txtcodigo.TabIndex = 89
        '
        'txtnombres
        '
        Me.txtnombres.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtnombres.Location = New System.Drawing.Point(55, 60)
        Me.txtnombres.MaxLength = 30
        Me.txtnombres.Name = "txtnombres"
        Me.txtnombres.ReadOnly = True
        Me.txtnombres.Size = New System.Drawing.Size(189, 20)
        Me.txtnombres.TabIndex = 90
        '
        'dtgestudiante
        '
        Me.dtgestudiante.AllowUserToAddRows = False
        Me.dtgestudiante.AllowUserToDeleteRows = False
        Me.dtgestudiante.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dtgestudiante.Location = New System.Drawing.Point(290, 14)
        Me.dtgestudiante.Name = "dtgestudiante"
        Me.dtgestudiante.ReadOnly = True
        Me.dtgestudiante.Size = New System.Drawing.Size(284, 89)
        Me.dtgestudiante.TabIndex = 0
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(6, 64)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(52, 13)
        Me.Label6.TabIndex = 92
        Me.Label6.Text = "Nombres:"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtaciclo)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.txtacreditos)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.btnnuevaasignatura)
        Me.GroupBox2.Controls.Add(Me.btnbuscarasignatura)
        Me.GroupBox2.Controls.Add(Me.txtbusquedaasignatura)
        Me.GroupBox2.Controls.Add(Me.txtatipo)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.txtacodigo)
        Me.GroupBox2.Controls.Add(Me.txtanombre)
        Me.GroupBox2.Controls.Add(Me.dtgasignatura)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Location = New System.Drawing.Point(28, 183)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(580, 130)
        Me.GroupBox2.TabIndex = 89
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Asignatura"
        '
        'txtaciclo
        '
        Me.txtaciclo.Location = New System.Drawing.Point(254, 82)
        Me.txtaciclo.MaxLength = 30
        Me.txtaciclo.Name = "txtaciclo"
        Me.txtaciclo.ReadOnly = True
        Me.txtaciclo.Size = New System.Drawing.Size(40, 20)
        Me.txtaciclo.TabIndex = 99
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(218, 87)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(33, 13)
        Me.Label10.TabIndex = 100
        Me.Label10.Text = "Ciclo:"
        '
        'txtacreditos
        '
        Me.txtacreditos.Location = New System.Drawing.Point(176, 82)
        Me.txtacreditos.MaxLength = 30
        Me.txtacreditos.Name = "txtacreditos"
        Me.txtacreditos.ReadOnly = True
        Me.txtacreditos.Size = New System.Drawing.Size(36, 20)
        Me.txtacreditos.TabIndex = 98
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(130, 86)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(48, 13)
        Me.Label9.TabIndex = 97
        Me.Label9.Text = "Créditos:"
        '
        'btnnuevaasignatura
        '
        Me.btnnuevaasignatura.Location = New System.Drawing.Point(233, 14)
        Me.btnnuevaasignatura.Name = "btnnuevaasignatura"
        Me.btnnuevaasignatura.Size = New System.Drawing.Size(51, 23)
        Me.btnnuevaasignatura.TabIndex = 89
        Me.btnnuevaasignatura.Text = "Nuevo"
        Me.btnnuevaasignatura.UseVisualStyleBackColor = True
        '
        'btnbuscarasignatura
        '
        Me.btnbuscarasignatura.Location = New System.Drawing.Point(168, 14)
        Me.btnbuscarasignatura.Name = "btnbuscarasignatura"
        Me.btnbuscarasignatura.Size = New System.Drawing.Size(59, 23)
        Me.btnbuscarasignatura.TabIndex = 96
        Me.btnbuscarasignatura.Text = "&Buscar"
        Me.btnbuscarasignatura.UseVisualStyleBackColor = True
        '
        'txtbusquedaasignatura
        '
        Me.txtbusquedaasignatura.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtbusquedaasignatura.Location = New System.Drawing.Point(6, 14)
        Me.txtbusquedaasignatura.Name = "txtbusquedaasignatura"
        Me.txtbusquedaasignatura.Size = New System.Drawing.Size(156, 20)
        Me.txtbusquedaasignatura.TabIndex = 95
        '
        'txtatipo
        '
        Me.txtatipo.Location = New System.Drawing.Point(39, 83)
        Me.txtatipo.MaxLength = 30
        Me.txtatipo.Name = "txtatipo"
        Me.txtatipo.ReadOnly = True
        Me.txtatipo.Size = New System.Drawing.Size(87, 20)
        Me.txtatipo.TabIndex = 91
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 42)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(43, 13)
        Me.Label4.TabIndex = 88
        Me.Label4.Text = "Código:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 86)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(31, 13)
        Me.Label5.TabIndex = 94
        Me.Label5.Text = "Tipo:"
        '
        'txtacodigo
        '
        Me.txtacodigo.Location = New System.Drawing.Point(55, 37)
        Me.txtacodigo.Name = "txtacodigo"
        Me.txtacodigo.ReadOnly = True
        Me.txtacodigo.Size = New System.Drawing.Size(57, 20)
        Me.txtacodigo.TabIndex = 89
        '
        'txtanombre
        '
        Me.txtanombre.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtanombre.Location = New System.Drawing.Point(74, 60)
        Me.txtanombre.MaxLength = 30
        Me.txtanombre.Name = "txtanombre"
        Me.txtanombre.ReadOnly = True
        Me.txtanombre.Size = New System.Drawing.Size(189, 20)
        Me.txtanombre.TabIndex = 90
        '
        'dtgasignatura
        '
        Me.dtgasignatura.AllowUserToAddRows = False
        Me.dtgasignatura.AllowUserToDeleteRows = False
        Me.dtgasignatura.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dtgasignatura.Location = New System.Drawing.Point(300, 14)
        Me.dtgasignatura.Name = "dtgasignatura"
        Me.dtgasignatura.ReadOnly = True
        Me.dtgasignatura.Size = New System.Drawing.Size(274, 89)
        Me.dtgasignatura.TabIndex = 0
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(6, 64)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(66, 13)
        Me.Label8.TabIndex = 92
        Me.Label8.Text = "Descripción:"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.txtgrupoaula)
        Me.GroupBox3.Controls.Add(Me.Label12)
        Me.GroupBox3.Controls.Add(Me.btnnuevaaula)
        Me.GroupBox3.Controls.Add(Me.btnbuscaraula)
        Me.GroupBox3.Controls.Add(Me.txtbusquedaaula)
        Me.GroupBox3.Controls.Add(Me.txtvacantesaula)
        Me.GroupBox3.Controls.Add(Me.Label13)
        Me.GroupBox3.Controls.Add(Me.Label14)
        Me.GroupBox3.Controls.Add(Me.txtcodigoaula)
        Me.GroupBox3.Controls.Add(Me.txtnombreaula)
        Me.GroupBox3.Controls.Add(Me.dtgaula)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Location = New System.Drawing.Point(28, 319)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(580, 123)
        Me.GroupBox3.TabIndex = 90
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Aula"
        '
        'txtgrupoaula
        '
        Me.txtgrupoaula.Location = New System.Drawing.Point(217, 82)
        Me.txtgrupoaula.MaxLength = 30
        Me.txtgrupoaula.Name = "txtgrupoaula"
        Me.txtgrupoaula.ReadOnly = True
        Me.txtgrupoaula.Size = New System.Drawing.Size(45, 20)
        Me.txtgrupoaula.TabIndex = 98
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(172, 86)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(39, 13)
        Me.Label12.TabIndex = 97
        Me.Label12.Text = "Grupo:"
        '
        'btnnuevaaula
        '
        Me.btnnuevaaula.Location = New System.Drawing.Point(233, 14)
        Me.btnnuevaaula.Name = "btnnuevaaula"
        Me.btnnuevaaula.Size = New System.Drawing.Size(51, 23)
        Me.btnnuevaaula.TabIndex = 89
        Me.btnnuevaaula.Text = "Nuevo"
        Me.btnnuevaaula.UseVisualStyleBackColor = True
        '
        'btnbuscaraula
        '
        Me.btnbuscaraula.Location = New System.Drawing.Point(168, 14)
        Me.btnbuscaraula.Name = "btnbuscaraula"
        Me.btnbuscaraula.Size = New System.Drawing.Size(59, 23)
        Me.btnbuscaraula.TabIndex = 96
        Me.btnbuscaraula.Text = "&Buscar"
        Me.btnbuscaraula.UseVisualStyleBackColor = True
        '
        'txtbusquedaaula
        '
        Me.txtbusquedaaula.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtbusquedaaula.Location = New System.Drawing.Point(6, 14)
        Me.txtbusquedaaula.Name = "txtbusquedaaula"
        Me.txtbusquedaaula.Size = New System.Drawing.Size(156, 20)
        Me.txtbusquedaaula.TabIndex = 95
        '
        'txtvacantesaula
        '
        Me.txtvacantesaula.Location = New System.Drawing.Point(78, 83)
        Me.txtvacantesaula.MaxLength = 30
        Me.txtvacantesaula.Name = "txtvacantesaula"
        Me.txtvacantesaula.ReadOnly = True
        Me.txtvacantesaula.Size = New System.Drawing.Size(87, 20)
        Me.txtvacantesaula.TabIndex = 91
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(6, 42)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(43, 13)
        Me.Label13.TabIndex = 88
        Me.Label13.Text = "Código:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(6, 86)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(70, 13)
        Me.Label14.TabIndex = 94
        Me.Label14.Text = "Nº Vacantes:"
        '
        'txtcodigoaula
        '
        Me.txtcodigoaula.Location = New System.Drawing.Point(55, 37)
        Me.txtcodigoaula.Name = "txtcodigoaula"
        Me.txtcodigoaula.ReadOnly = True
        Me.txtcodigoaula.Size = New System.Drawing.Size(57, 20)
        Me.txtcodigoaula.TabIndex = 89
        '
        'txtnombreaula
        '
        Me.txtnombreaula.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtnombreaula.Location = New System.Drawing.Point(74, 60)
        Me.txtnombreaula.MaxLength = 30
        Me.txtnombreaula.Name = "txtnombreaula"
        Me.txtnombreaula.ReadOnly = True
        Me.txtnombreaula.Size = New System.Drawing.Size(189, 20)
        Me.txtnombreaula.TabIndex = 90
        '
        'dtgaula
        '
        Me.dtgaula.AllowUserToAddRows = False
        Me.dtgaula.AllowUserToDeleteRows = False
        Me.dtgaula.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dtgaula.Location = New System.Drawing.Point(300, 14)
        Me.dtgaula.Name = "dtgaula"
        Me.dtgaula.ReadOnly = True
        Me.dtgaula.Size = New System.Drawing.Size(274, 89)
        Me.dtgaula.TabIndex = 0
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(6, 64)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(66, 13)
        Me.Label15.TabIndex = 92
        Me.Label15.Text = "Descripción:"
        '
        'btnmatricular
        '
        Me.btnmatricular.BackColor = System.Drawing.Color.Aqua
        Me.btnmatricular.Location = New System.Drawing.Point(632, 96)
        Me.btnmatricular.Name = "btnmatricular"
        Me.btnmatricular.Size = New System.Drawing.Size(95, 51)
        Me.btnmatricular.TabIndex = 91
        Me.btnmatricular.Text = "&MATRICULAR"
        Me.btnmatricular.UseVisualStyleBackColor = False
        '
        'frmMatricula
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(739, 454)
        Me.Controls.Add(Me.btnmatricular)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.dtpfechamatricula)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmMatricula"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "frmMatricula"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.dtgestudiante, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.dtgasignatura, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.dtgaula, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As Label
    Friend WithEvents dtpfechamatricula As DateTimePicker
    Friend WithEvents Label2 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label3 As Label
    Friend WithEvents dtgestudiante As DataGridView
    Friend WithEvents txtapellidos As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents txtcodigo As TextBox
    Friend WithEvents txtnombres As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents btnbuscar As Button
    Friend WithEvents txtbusqueda As TextBox
    Friend WithEvents btnnuevo As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents txtaciclo As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents txtacreditos As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents btnnuevaasignatura As Button
    Friend WithEvents btnbuscarasignatura As Button
    Friend WithEvents txtbusquedaasignatura As TextBox
    Friend WithEvents txtatipo As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txtacodigo As TextBox
    Friend WithEvents txtanombre As TextBox
    Friend WithEvents dtgasignatura As DataGridView
    Friend WithEvents Label8 As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents txtgrupoaula As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents btnnuevaaula As Button
    Friend WithEvents btnbuscaraula As Button
    Friend WithEvents txtbusquedaaula As TextBox
    Friend WithEvents txtvacantesaula As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents txtcodigoaula As TextBox
    Friend WithEvents txtnombreaula As TextBox
    Friend WithEvents dtgaula As DataGridView
    Friend WithEvents Label15 As Label
    Friend WithEvents btnmatricular As Button
End Class
