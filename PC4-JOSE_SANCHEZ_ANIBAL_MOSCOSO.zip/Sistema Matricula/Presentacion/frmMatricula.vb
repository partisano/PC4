﻿Imports Negocio
Imports Entidades
Public Class frmMatricula
    Dim objetoestudianteN As New clsestudianteN
    Dim objetoestudianteE As New clsEstudianteE
    Dim objetoasignaturaN As New clsAsignaturaN
    Dim objetoasignaturaE As New clsAsignaturaE
    Dim objetoaulaN As New clsaulaN
    Dim objetoaulaE As New clsAulaE
    Dim matriculaE As New clsMatriculaE
    Dim matriculaN As New clsMatriculaN
    Private Sub btnnuevo_Click(sender As Object, e As EventArgs) Handles btnnuevo.Click
        frmEstudiante.ShowDialog()
    End Sub

    Private Sub frmMatricula_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim encontro As Boolean = False
        For index = 0 To frmlogin.permisos.Count - 1
            If frmlogin.permisos(index).ToString = "frmMatricula" Then
                encontro = True
            End If
        Next
        If encontro <> True Then
            Close()
        End If
        dtgestudiante.DataSource = objetoestudianteN.listarestudianteN
        dtgasignatura.DataSource = objetoasignaturaN.listarasignaturaN
        dtgaula.DataSource = objetoaulaN.listaraulaN
    End Sub

    Private Sub frmMatricula_Activated(sender As Object, e As EventArgs) Handles MyBase.Activated
        dtgestudiante.DataSource = objetoestudianteN.listarestudianteN
        dtgasignatura.DataSource = objetoasignaturaN.listarasignaturaN
        dtgaula.DataSource = objetoaulaN.listaraulaN
    End Sub

    Private Sub btnbuscar_Click(sender As Object, e As EventArgs) Handles btnbuscar.Click
        If txtbusqueda.Text.Trim = String.Empty Then
            dtgestudiante.DataSource = objetoestudianteN.listarestudianteN()
        Else
            objetoestudianteE.Busqueda1 = txtbusqueda.Text.Trim
            dtgestudiante.DataSource = objetoestudianteN.buscarestudianteN(objetoestudianteE)
        End If
    End Sub

    Private Sub dtgestudiante_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dtgestudiante.CellClick
        txtcodigo.Text = dtgestudiante.Rows(e.RowIndex).Cells(0).Value 'Caputar el id de la persona seleccionada
        txtnombres.Text = dtgestudiante.Rows(e.RowIndex).Cells(1).Value
        txtapellidos.Text = dtgestudiante.Rows(e.RowIndex).Cells(2).Value
    End Sub

    Private Sub btnnuevaasignatura_Click(sender As Object, e As EventArgs) Handles btnnuevaasignatura.Click
        frmAsignatura.ShowDialog()
    End Sub

    Private Sub btnbuscarasignatura_Click(sender As Object, e As EventArgs) Handles btnbuscarasignatura.Click
        If txtbusquedaasignatura.Text.Trim = String.Empty Then
            dtgasignatura.DataSource = objetoasignaturaN.listarasignaturaN()
        Else
            objetoasignaturaE.Busqueda1 = txtbusquedaasignatura.Text.Trim
            dtgasignatura.DataSource = objetoasignaturaN.buscarasignaturaN(objetoasignaturaE)
        End If
    End Sub

    Private Sub dtgasignatura_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dtgasignatura.CellClick
        txtacodigo.Text = dtgasignatura.Rows(e.RowIndex).Cells(0).Value 'Caputar el id de la persona seleccionada
        txtanombre.Text = dtgasignatura.Rows(e.RowIndex).Cells(1).Value
        txtacreditos.Text = dtgasignatura.Rows(e.RowIndex).Cells(2).Value
        txtatipo.Text = dtgasignatura.Rows(e.RowIndex).Cells(3).Value
        txtaciclo.Text = dtgasignatura.Rows(e.RowIndex).Cells(4).Value

    End Sub

    Private Sub btnnuevaaula_Click(sender As Object, e As EventArgs) Handles btnnuevaaula.Click
        frmAula.ShowDialog()
    End Sub

    Private Sub btnbuscaraula_Click(sender As Object, e As EventArgs) Handles btnbuscaraula.Click
        If txtbusquedaaula.Text.Trim = String.Empty Then
            dtgaula.DataSource = objetoaulaN.listaraulaN()
        Else
            objetoaulaE.Busqueda1 = txtbusquedaaula.Text.Trim
            dtgaula.DataSource = objetoaulaN.buscaraulaN(objetoaulaE)
        End If
    End Sub

    Private Sub dtgaula_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dtgaula.CellClick
        txtcodigoaula.Text = dtgaula.Rows(e.RowIndex).Cells(0).Value 'Caputar el id de la persona seleccionada
        txtnombreaula.Text = dtgaula.Rows(e.RowIndex).Cells(1).Value
        txtvacantesaula.Text = dtgaula.Rows(e.RowIndex).Cells(2).Value
        txtgrupoaula.Text = dtgaula.Rows(e.RowIndex).Cells(3).Value

    End Sub

    Private Sub btnmatricular_Click(sender As Object, e As EventArgs) Handles btnmatricular.Click
        If txtcodigo.Text.Trim = String.Empty Then
            MsgBox("Seleccione estudiante")
            dtgestudiante.Focus()
            Exit Sub
        End If
        If txtacodigo.Text.Trim = String.Empty Then
            MsgBox("Seleccione asignatura")
            dtgasignatura.Focus()
            Exit Sub
        End If
        If txtcodigoaula.Text.Trim = String.Empty Then
            MsgBox("Seleccione aula")
            dtgaula.Focus()
            Exit Sub
        End If
        If txtcodigoaula.Text.Trim <> String.Empty And Val(txtvacantesaula.Text.Trim) <= 0 Then
            MsgBox("No hay vacantes para el aula seleccionada")
            dtgaula.Focus()
            Exit Sub
        End If

        matriculaE.Fechamatricula1 = dtpfechamatricula.Value
        matriculaE.IdEstudiante1 = txtcodigo.Text
        matriculaE.IdAsignatura1 = txtacodigo.Text
        matriculaE.IdAula1 = txtcodigoaula.Text
        matriculaE.Idusuario1 = frmlogin.idusuario
        matriculaN.registrarmatriculaN(matriculaE)
        MsgBox("Registro de matrícula OK")
        limpiar()

    End Sub

    Sub limpiar()
        REM controles estudiante
        txtcodigo.Clear()
        txtnombres.Clear()
        txtapellidos.Clear()

        REM controles asignatura
        txtacodigo.Clear()
        txtanombre.Clear()
        txtatipo.Clear()
        txtacreditos.Clear()
        txtacreditos.Clear()

        REM controles aula
        txtcodigoaula.Clear()
        txtnombreaula.Clear()
        txtvacantesaula.Clear()
        txtgrupoaula.Clear()


    End Sub
End Class