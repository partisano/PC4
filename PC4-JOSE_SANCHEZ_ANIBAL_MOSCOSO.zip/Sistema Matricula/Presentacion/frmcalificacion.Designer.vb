﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmcalificacion
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cbxasignaturas = New System.Windows.Forms.ComboBox()
        Me.dtgdatos = New System.Windows.Forms.DataGridView()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtestudiante = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cbxtipoevaluación = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtnota = New System.Windows.Forms.TextBox()
        Me.btnregistrarcalificacion = New System.Windows.Forms.Button()
        Me.txtcodigomatricula = New System.Windows.Forms.TextBox()
        CType(Me.dtgdatos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(128, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(145, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "REGISTRAR CALIFICACIÓN"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(18, 53)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(116, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Seleccione Asignatura:"
        '
        'cbxasignaturas
        '
        Me.cbxasignaturas.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxasignaturas.FormattingEnabled = True
        Me.cbxasignaturas.Location = New System.Drawing.Point(140, 50)
        Me.cbxasignaturas.Name = "cbxasignaturas"
        Me.cbxasignaturas.Size = New System.Drawing.Size(133, 21)
        Me.cbxasignaturas.TabIndex = 2
        '
        'dtgdatos
        '
        Me.dtgdatos.AllowUserToAddRows = False
        Me.dtgdatos.AllowUserToDeleteRows = False
        Me.dtgdatos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dtgdatos.Location = New System.Drawing.Point(21, 77)
        Me.dtgdatos.Name = "dtgdatos"
        Me.dtgdatos.ReadOnly = True
        Me.dtgdatos.Size = New System.Drawing.Size(435, 103)
        Me.dtgdatos.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(55, 210)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(60, 13)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Estudiante:"
        '
        'txtestudiante
        '
        Me.txtestudiante.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtestudiante.Location = New System.Drawing.Point(121, 207)
        Me.txtestudiante.Name = "txtestudiante"
        Me.txtestudiante.ReadOnly = True
        Me.txtestudiante.Size = New System.Drawing.Size(219, 20)
        Me.txtestudiante.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(18, 236)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(101, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Tipo de evaluación:"
        '
        'cbxtipoevaluación
        '
        Me.cbxtipoevaluación.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxtipoevaluación.FormattingEnabled = True
        Me.cbxtipoevaluación.Location = New System.Drawing.Point(121, 233)
        Me.cbxtipoevaluación.Name = "cbxtipoevaluación"
        Me.cbxtipoevaluación.Size = New System.Drawing.Size(133, 21)
        Me.cbxtipoevaluación.TabIndex = 6
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(82, 263)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(33, 13)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "Nota:"
        '
        'txtnota
        '
        Me.txtnota.Location = New System.Drawing.Point(121, 260)
        Me.txtnota.Name = "txtnota"
        Me.txtnota.Size = New System.Drawing.Size(100, 20)
        Me.txtnota.TabIndex = 8
        '
        'btnregistrarcalificacion
        '
        Me.btnregistrarcalificacion.Location = New System.Drawing.Point(164, 286)
        Me.btnregistrarcalificacion.Name = "btnregistrarcalificacion"
        Me.btnregistrarcalificacion.Size = New System.Drawing.Size(133, 37)
        Me.btnregistrarcalificacion.TabIndex = 9
        Me.btnregistrarcalificacion.Text = "&Registrar calificación"
        Me.btnregistrarcalificacion.UseVisualStyleBackColor = True
        '
        'txtcodigomatricula
        '
        Me.txtcodigomatricula.Location = New System.Drawing.Point(121, 183)
        Me.txtcodigomatricula.Name = "txtcodigomatricula"
        Me.txtcodigomatricula.ReadOnly = True
        Me.txtcodigomatricula.Size = New System.Drawing.Size(219, 20)
        Me.txtcodigomatricula.TabIndex = 10
        Me.txtcodigomatricula.Visible = False
        '
        'frmcalificacion
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(468, 335)
        Me.Controls.Add(Me.txtcodigomatricula)
        Me.Controls.Add(Me.btnregistrarcalificacion)
        Me.Controls.Add(Me.txtnota)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.cbxtipoevaluación)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtestudiante)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.dtgdatos)
        Me.Controls.Add(Me.cbxasignaturas)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.KeyPreview = True
        Me.Name = "frmcalificacion"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "frmcalificacion"
        CType(Me.dtgdatos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents cbxasignaturas As ComboBox
    Friend WithEvents dtgdatos As DataGridView
    Friend WithEvents Label4 As Label
    Friend WithEvents txtestudiante As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents cbxtipoevaluación As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtnota As TextBox
    Friend WithEvents btnregistrarcalificacion As Button
    Friend WithEvents txtcodigomatricula As TextBox
End Class
