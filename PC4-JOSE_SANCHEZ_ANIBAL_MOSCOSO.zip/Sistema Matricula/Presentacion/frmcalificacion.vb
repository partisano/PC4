﻿Imports Negocio
Imports Entidades
Public Class frmcalificacion
    Dim asignaturaN As New clsAsignaturaN
    Dim asignaturaE As New clsAsignaturaE
    Dim matriculaN As New clsmatriculaN
    Dim matriculaE As New clsMatriculaE
    Dim tipoevaluacionN As New clstipoevaluacionN
    Dim tipoevaluacionE As New clstipoEvaluacionE
    Dim calificacionN As New clscalificacionN
    Dim calificacionE As New clscalificacionE


    Private Sub frmcalificacion_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim encontro As Boolean = False
        For index = 0 To frmlogin.permisos.Count - 1
            If frmlogin.permisos(index).ToString = "frmcalificacion" Then
                encontro = True
            End If
        Next
        If encontro <> True Then
            Close()
        End If

        cbxasignaturas.DisplayMember = "Nombre"
        cbxasignaturas.ValueMember = "idAsignatura"
        cbxasignaturas.DataSource = asignaturaN.listarasignaturaN

        cbxtipoevaluación.DisplayMember = "Descripcion"
        cbxtipoevaluación.ValueMember = "idtipoevaluacion"
        cbxtipoevaluación.DataSource = tipoevaluacionN.listartipoevaluacionN
    End Sub

    Private Sub cbxasignaturas_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbxasignaturas.SelectedIndexChanged
        matriculaE.IdAsignatura1 = cbxasignaturas.SelectedValue
        dtgdatos.DataSource = matriculaN.matriculadosporasignaturaN(matriculaE)
    End Sub

    Private Sub dtgdatos_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dtgdatos.CellClick
        txtcodigomatricula.Text = dtgdatos.Rows(e.RowIndex).Cells(0).Value
        txtestudiante.Text = dtgdatos.Rows(e.RowIndex).Cells(2).Value 'Caputar el id de la persona seleccionada

    End Sub



    Private Sub txtnota_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtnota.KeyPress
        If (e.KeyChar >= Chr(48) And e.KeyChar <= Chr(57)) Or e.KeyChar = Chr(46) Or e.KeyChar = Chr(8) Then
            e.Handled = False
        Else
            e.Handled = True

        End If
    End Sub

    Private Sub btnregistrarcalificacion_Click(sender As Object, e As EventArgs) Handles btnregistrarcalificacion.Click
        If txtcodigomatricula.Text.Trim = String.Empty Then
            MsgBox("Debe seleccionar estudiante")
            dtgdatos.Focus()
            Exit Sub
        End If
        If cbxtipoevaluación.Text.Trim = String.Empty Then
            MsgBox("Seleccione tipo de evaluacion")
            cbxtipoevaluación.Focus()
            Exit Sub
        End If
        If txtnota.Text.Trim = String.Empty Then
            MsgBox("Ingrese nota a calificar")
            txtnota.Focus()
            Exit Sub
        End If

        calificacionE.Idmatricula1 = txtcodigomatricula.Text
        calificacionE.Idtipoevaluacion1 = cbxtipoevaluación.SelectedValue
        calificacionE.Nota1 = txtnota.Text

        calificacionN.registrarcalificacionN(calificacionE)
        MsgBox("Calificación registrada OK")
        txtnota.Clear()
    End Sub
End Class