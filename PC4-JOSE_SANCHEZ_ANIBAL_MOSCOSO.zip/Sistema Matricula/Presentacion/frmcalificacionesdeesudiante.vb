﻿Imports Negocio
Imports Entidades
Public Class frmcalificacionesdeesudiante
    Dim estudianteE As New clsEstudianteE
    Dim estudianteN As New clsestudianteN
    Dim asignaturaE As New clsAsignaturaE
    Dim asignaturaN As New clsAsignaturaN
    Dim matriculaE As New clsMatriculaE
    Dim matriculaN As New clsmatriculaN

    Private Sub btncalificaciones_Click(sender As Object, e As EventArgs) Handles btncalificaciones.Click
        If cbxestudiante.Text.Trim = String.Empty Then
            MsgBox("Debe seleccionar estudiante")
            cbxestudiante.Focus()
            Exit Sub
        End If
        If cbxasignatura.Text.Trim = String.Empty Then
            MsgBox("Debe seleccionar asignatura")
            cbxasignatura.Focus()
            Exit Sub
        End If
        matriculaE.IdEstudiante1 = cbxestudiante.SelectedValue
        matriculaE.IdAsignatura1 = cbxasignatura.SelectedValue
        dtgdatos.DataSource = matriculaN.matriculaycalificacionesxalumnoycursoN(matriculaE)

    End Sub

    Private Sub frmcalificacionesdeesudiante_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim encontro As Boolean = False
        For index = 0 To frmlogin.permisos.Count - 1
            If frmlogin.permisos(index).ToString = "frmcalificacionesdeestudiante" Then
                encontro = True
            End If
        Next
        If encontro <> True Then
            Close()
        End If

        cbxestudiante.DisplayMember = "Nombres"
        cbxestudiante.ValueMember = "idEstudiante"
        cbxestudiante.DataSource = estudianteN.listarestudianteN

        cbxasignatura.DisplayMember = "Nombre"
        cbxasignatura.ValueMember = "idAsignatura"
        cbxasignatura.DataSource = asignaturaN.listarasignaturaN
    End Sub
End Class