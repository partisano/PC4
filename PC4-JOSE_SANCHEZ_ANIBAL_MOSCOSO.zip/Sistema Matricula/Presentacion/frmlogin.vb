﻿Imports Negocio
Imports Entidades
Public Class frmlogin

    Dim usuarioE As New clsusuarioE
    Dim usuarioN As New clsusuarioN
    Public permisos As ArrayList = New ArrayList()
    Public idusuario As Integer
    Public usuario As String
    Public tipousuario As String
    Public idtipousuario As Integer
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If txtusuario.Text.Trim = String.Empty Then
            MsgBox("Ingrese usuario")
            txtusuario.Focus()
            Exit Sub
        End If
        If txtclave.Text.Trim = String.Empty Then
            MsgBox("Ingrese clave")
            txtusuario.Focus()
            Exit Sub
        End If
        usuarioE.Usuario1 = txtusuario.Text
        usuarioE.Clave1 = txtclave.Text
        Dim dt As New DataTable
        dt = usuarioN.logueoN(usuarioE)
        If dt.Rows.Count > 0 Then
            idusuario = dt.Rows(0)(0)
            usuario = dt.Rows(0)(1)
            tipousuario = dt.Rows(0)(2)
            idtipousuario = dt.Rows(0)(4)
            For index = 0 To dt.Rows.Count - 1
                permisos.Add(dt.Rows(index)(3))
            Next

            Me.Hide()
            frmprincipal.ShowDialog()
        Else
            MsgBox("Datos incorrectos o usuario no existe en nuestra base de datos o usuario no tiene permisos")
        End If
    End Sub

    Private Sub frmlogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class