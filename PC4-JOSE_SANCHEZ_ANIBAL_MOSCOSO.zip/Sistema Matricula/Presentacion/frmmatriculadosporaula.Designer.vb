﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmmatriculadosporaula
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cbxaula = New System.Windows.Forms.ComboBox()
        Me.dtgdatos = New System.Windows.Forms.DataGridView()
        CType(Me.dtgdatos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(190, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(156, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "MATRICULADOSA POR AULA"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(23, 53)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(87, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Seleccione Aula:"
        '
        'cbxaula
        '
        Me.cbxaula.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxaula.FormattingEnabled = True
        Me.cbxaula.Location = New System.Drawing.Point(116, 50)
        Me.cbxaula.Name = "cbxaula"
        Me.cbxaula.Size = New System.Drawing.Size(148, 21)
        Me.cbxaula.TabIndex = 2
        '
        'dtgdatos
        '
        Me.dtgdatos.AllowUserToAddRows = False
        Me.dtgdatos.AllowUserToDeleteRows = False
        Me.dtgdatos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dtgdatos.Location = New System.Drawing.Point(12, 90)
        Me.dtgdatos.Name = "dtgdatos"
        Me.dtgdatos.ReadOnly = True
        Me.dtgdatos.Size = New System.Drawing.Size(596, 173)
        Me.dtgdatos.TabIndex = 3
        '
        'frmmatriculadosporaula
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(620, 275)
        Me.Controls.Add(Me.dtgdatos)
        Me.Controls.Add(Me.cbxaula)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmmatriculadosporaula"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "frmmatriculdosporaula"
        CType(Me.dtgdatos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents cbxaula As ComboBox
    Friend WithEvents dtgdatos As DataGridView
End Class
