﻿Imports Negocio
Imports Entidades
Public Class frmmatriculadosporaula
    Dim aulaN As New clsaulaN
    Dim aulaE As New clsAulaE
    Dim matriculaN As New clsmatriculaN
    Dim matriculaE As New clsMatriculaE


    Private Sub cbxaula_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbxaula.SelectedIndexChanged
        matriculaE.IdAula1 = cbxaula.SelectedValue
        dtgdatos.DataSource = matriculaN.matriculadosporaulaN(matriculaE)
    End Sub

    Private Sub frmmatriculadosporaula_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim encontro As Boolean = False
        For index = 0 To frmlogin.permisos.Count - 1
            If frmlogin.permisos(index).ToString = "frmmatriculadosporaula" Then
                encontro = True
            End If
        Next
        If encontro <> True Then
            Close()
        End If
        cbxaula.DisplayMember = "Nombre"
        cbxaula.ValueMember = "idAula"
        cbxaula.DataSource = aulaN.listaraulaN
    End Sub
End Class