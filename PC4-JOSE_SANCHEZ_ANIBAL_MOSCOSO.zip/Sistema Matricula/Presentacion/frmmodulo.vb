﻿Imports Negocio
Imports Entidades
Imports System.Reflection

Public Class frmmodulo
    Dim elementoE As New clselementoE
    Dim elementoN As New clselementoN


    Private Sub btnregistrar_Click(sender As Object, e As EventArgs) Handles btnregistrar.Click
        Try
            If txtcodigo.Text.Trim <> String.Empty Then
            MsgBox("Debe limpiar el código")
            btnLimpiar.Focus()
            Exit Sub
        End If

        If cbxformularios.Text.Trim = String.Empty Then
            MsgBox("Ingrese descripción de elemento")
            cbxformularios.Focus()
            Exit Sub
        End If
        elementoE.Descripcion1 = cbxformularios.Text
        elementoN.registrarelementoN(elementoE)
        MsgBox("Registro OK")
        dtgdatos.DataSource = elementoN.listarelementoN()
        cbxformularios.Text = ""

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnmodificar_Click(sender As Object, e As EventArgs) Handles btnmodificar.Click
        Try
            If txtcodigo.Text.Trim = String.Empty Then
            MsgBox("Seleccione elemento de la lista")
            dtgdatos.Focus()
            Exit Sub
        End If
        If cbxformularios.Text.Trim = String.Empty Then
            MsgBox("Ingrese descripción de elemento")
            cbxformularios.Focus()
            Exit Sub
        End If

        elementoE.Idelemento1 = txtcodigo.Text
        elementoE.Descripcion1 = cbxformularios.Text

        elementoN.modificarelementoN(elementoE)
        MsgBox("Modificado OK")
        dtgdatos.DataSource = elementoN.listarelementoN()
        txtcodigo.Clear()
        cbxformularios.Text = ""

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub btneliminar_Click(sender As Object, e As EventArgs) Handles btneliminar.Click
        Try
            If txtcodigo.Text.Trim = String.Empty Then
            MsgBox("Seleccione elemento de la lista")
            dtgdatos.Focus()
            Exit Sub
        End If
        elementoE.Idelemento1 = txtcodigo.Text
        elementoN.eliminarelementoN(elementoE)
        MsgBox("ELiminado OK")
        dtgdatos.DataSource = elementoN.listarelementoN()
        txtcodigo.Clear()
        cbxformularios.Text = ""

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub btnLimpiar_Click(sender As Object, e As EventArgs) Handles btnLimpiar.Click
        txtcodigo.Clear()
        cbxformularios.Text = ""
    End Sub

    Private Sub dtgdatos_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dtgdatos.CellClick
        txtcodigo.Text = dtgdatos.Rows(e.RowIndex).Cells(0).Value 'Caputar el id de la persona seleccionada
        cbxformularios.Text = dtgdatos.Rows(e.RowIndex).Cells(1).Value

    End Sub



    Dim ass As Assembly = Reflection.Assembly.GetExecutingAssembly
    Private Sub mostrarForms()
        ' llena una colección con los formularios de esta aplicación
        ' estén o no en memoria.
        ' Muestra el resultado en un listbox

        cbxformularios.Items.Clear()

        For Each t As Type In ass.GetTypes
            Dim nombreTipo = t.BaseType.Name
            ' También tendrá My.Application: (solo en VB)
            ' <espacio de nombres>.My.MyApplication
            If nombreTipo.ToLower().Contains("form") Then
                cbxformularios.Items.Add(t.Name)
            End If
        Next
        cbxformularios.Items.RemoveAt(0)
        cbxformularios.Items.Remove("frmlogin")
        cbxformularios.Items.Remove("frmprincipal")

    End Sub

    Private Sub btnbuscar_Click(sender As Object, e As EventArgs) Handles btnbuscar.Click
        If txtbusqueda.Text.Trim = String.Empty Then
            dtgdatos.DataSource = elementoN.listarelementoN()
        Else
            elementoE.Busqueda1 = txtbusqueda.Text.Trim
            dtgdatos.DataSource = elementoN.buscarelementoN(elementoE)
        End If
    End Sub

    Private Sub frmmodulo_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim encontro As Boolean = False
        For index = 0 To frmlogin.permisos.Count - 1
            If frmlogin.permisos(index).ToString = "frmmodulo" Then
                encontro = True
            End If
        Next
        If encontro <> True Then
            Close()
        End If
        mostrarForms()
        dtgdatos.DataSource = elementoN.listarelementoN()
    End Sub
End Class