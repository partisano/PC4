﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmordenmerito
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dtgdatos = New System.Windows.Forms.DataGridView()
        Me.cbxasignatura = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        CType(Me.dtgdatos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dtgdatos
        '
        Me.dtgdatos.AllowUserToAddRows = False
        Me.dtgdatos.AllowUserToDeleteRows = False
        Me.dtgdatos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dtgdatos.Location = New System.Drawing.Point(13, 98)
        Me.dtgdatos.Name = "dtgdatos"
        Me.dtgdatos.ReadOnly = True
        Me.dtgdatos.Size = New System.Drawing.Size(475, 245)
        Me.dtgdatos.TabIndex = 8
        '
        'cbxasignatura
        '
        Me.cbxasignatura.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxasignatura.FormattingEnabled = True
        Me.cbxasignatura.Location = New System.Drawing.Point(156, 51)
        Me.cbxasignatura.Name = "cbxasignatura"
        Me.cbxasignatura.Size = New System.Drawing.Size(183, 21)
        Me.cbxasignatura.TabIndex = 7
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(34, 59)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(116, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Seleccione Asignatura:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(142, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(208, 13)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "ORDEN DE MERITO POR ASIGNATURA"
        '
        'frmordenmerito
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(500, 355)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.dtgdatos)
        Me.Controls.Add(Me.cbxasignatura)
        Me.Controls.Add(Me.Label2)
        Me.Name = "frmordenmerito"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "frmordenmerito"
        CType(Me.dtgdatos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dtgdatos As DataGridView
    Friend WithEvents cbxasignatura As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
End Class
