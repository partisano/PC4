﻿Imports Negocio
Imports Entidades
Public Class frmordenmerito
    Dim asignaturaE As New clsAsignaturaE
    Dim asignaturaN As New clsAsignaturaN
    Dim matriculaE As New clsMatriculaE
    Dim matriculaN As New clsmatriculaN
    Private Sub frmordenmerito_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim encontro As Boolean = False
        For index = 0 To frmlogin.permisos.Count - 1
            If frmlogin.permisos(index).ToString = "frmordenmerito" Then
                encontro = True
            End If
        Next
        If encontro <> True Then
            Close()
        End If
        cbxasignatura.DisplayMember = "Nombre"
        cbxasignatura.ValueMember = "idAsignatura"
        cbxasignatura.DataSource = asignaturaN.listarasignaturaN
    End Sub

    Private Sub cbxasignatura_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbxasignatura.SelectedIndexChanged
        matriculaE.IdAsignatura1 = cbxasignatura.SelectedValue
        dtgdatos.DataSource = matriculaN.ordenmeritoxcursoN(matriculaE)

    End Sub
End Class