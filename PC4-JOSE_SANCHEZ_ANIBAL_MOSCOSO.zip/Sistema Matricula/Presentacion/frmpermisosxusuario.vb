﻿Imports Negocio
Imports Entidades
Public Class frmpermisosxusuario
    Dim detallepermisoN As New clsdetallepermisoN
    Dim detallepermisoE As New clsdetallepermisoE


    Private Sub frmpermisosxusuario_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim encontro As Boolean = False
        For index = 0 To frmlogin.permisos.Count - 1
            If frmlogin.permisos(index).ToString = "frmpermisosxusuario" Then
                encontro = True
            End If
        Next
        If encontro <> True Then
            Close()
        End If
        txtusuario.Text = frmusuario.usuarioseleccionado
        txttipo.Text = frmusuario.nombretipousuarioseleccionado
        detallepermisoE.Idtipousuario1 = frmusuario.tipousuarioseleccionado
        dtgpermisos.DataSource = detallepermisoN.buscardetallepermisoN(detallepermisoE)
    End Sub


End Class