﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmprincipal
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmprincipal))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.GruposToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AulasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AsignaturaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EstudianteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TiposDeEvaluacionesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MatriculaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MAtricularToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AlumnosMatriculadosPorAulaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CalificacionesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RegistrarNotasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VerCalificacionesDeEstudianteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OrdenDeMeritoPorCursoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PermisosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MatenimientoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TipoDeUsuariosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MantenimientoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UsuariosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MantenimientoToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblusuario = New System.Windows.Forms.Label()
        Me.lbltipousuario = New System.Windows.Forms.Label()
        Me.btncerrarsistema = New System.Windows.Forms.Button()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GruposToolStripMenuItem, Me.AulasToolStripMenuItem, Me.AsignaturaToolStripMenuItem, Me.EstudianteToolStripMenuItem, Me.TiposDeEvaluacionesToolStripMenuItem, Me.MatriculaToolStripMenuItem, Me.CalificacionesToolStripMenuItem, Me.PermisosToolStripMenuItem, Me.TipoDeUsuariosToolStripMenuItem, Me.UsuariosToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(927, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'GruposToolStripMenuItem
        '
        Me.GruposToolStripMenuItem.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GruposToolStripMenuItem.Name = "GruposToolStripMenuItem"
        Me.GruposToolStripMenuItem.Size = New System.Drawing.Size(62, 20)
        Me.GruposToolStripMenuItem.Text = "Grupos"
        Me.GruposToolStripMenuItem.Visible = False
        '
        'AulasToolStripMenuItem
        '
        Me.AulasToolStripMenuItem.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AulasToolStripMenuItem.Name = "AulasToolStripMenuItem"
        Me.AulasToolStripMenuItem.Size = New System.Drawing.Size(52, 20)
        Me.AulasToolStripMenuItem.Text = "Aulas"
        Me.AulasToolStripMenuItem.Visible = False
        '
        'AsignaturaToolStripMenuItem
        '
        Me.AsignaturaToolStripMenuItem.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AsignaturaToolStripMenuItem.Name = "AsignaturaToolStripMenuItem"
        Me.AsignaturaToolStripMenuItem.Size = New System.Drawing.Size(82, 20)
        Me.AsignaturaToolStripMenuItem.Text = "Asignatura"
        Me.AsignaturaToolStripMenuItem.Visible = False
        '
        'EstudianteToolStripMenuItem
        '
        Me.EstudianteToolStripMenuItem.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EstudianteToolStripMenuItem.Name = "EstudianteToolStripMenuItem"
        Me.EstudianteToolStripMenuItem.Size = New System.Drawing.Size(78, 20)
        Me.EstudianteToolStripMenuItem.Text = "Estudiante"
        Me.EstudianteToolStripMenuItem.Visible = False
        '
        'TiposDeEvaluacionesToolStripMenuItem
        '
        Me.TiposDeEvaluacionesToolStripMenuItem.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TiposDeEvaluacionesToolStripMenuItem.Name = "TiposDeEvaluacionesToolStripMenuItem"
        Me.TiposDeEvaluacionesToolStripMenuItem.Size = New System.Drawing.Size(139, 20)
        Me.TiposDeEvaluacionesToolStripMenuItem.Text = "Tipos de evaluación"
        Me.TiposDeEvaluacionesToolStripMenuItem.Visible = False
        '
        'MatriculaToolStripMenuItem
        '
        Me.MatriculaToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MAtricularToolStripMenuItem, Me.AlumnosMatriculadosPorAulaToolStripMenuItem})
        Me.MatriculaToolStripMenuItem.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MatriculaToolStripMenuItem.Name = "MatriculaToolStripMenuItem"
        Me.MatriculaToolStripMenuItem.Size = New System.Drawing.Size(75, 20)
        Me.MatriculaToolStripMenuItem.Text = "Matricula"
        Me.MatriculaToolStripMenuItem.Visible = False
        '
        'MAtricularToolStripMenuItem
        '
        Me.MAtricularToolStripMenuItem.Name = "MAtricularToolStripMenuItem"
        Me.MAtricularToolStripMenuItem.Size = New System.Drawing.Size(204, 22)
        Me.MAtricularToolStripMenuItem.Text = "Matricular"
        '
        'AlumnosMatriculadosPorAulaToolStripMenuItem
        '
        Me.AlumnosMatriculadosPorAulaToolStripMenuItem.Name = "AlumnosMatriculadosPorAulaToolStripMenuItem"
        Me.AlumnosMatriculadosPorAulaToolStripMenuItem.Size = New System.Drawing.Size(204, 22)
        Me.AlumnosMatriculadosPorAulaToolStripMenuItem.Text = "Matriculados por aula"
        '
        'CalificacionesToolStripMenuItem
        '
        Me.CalificacionesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RegistrarNotasToolStripMenuItem, Me.VerCalificacionesDeEstudianteToolStripMenuItem, Me.OrdenDeMeritoPorCursoToolStripMenuItem})
        Me.CalificacionesToolStripMenuItem.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CalificacionesToolStripMenuItem.Name = "CalificacionesToolStripMenuItem"
        Me.CalificacionesToolStripMenuItem.Size = New System.Drawing.Size(104, 20)
        Me.CalificacionesToolStripMenuItem.Text = "Calificaciones"
        Me.CalificacionesToolStripMenuItem.Visible = False
        '
        'RegistrarNotasToolStripMenuItem
        '
        Me.RegistrarNotasToolStripMenuItem.Name = "RegistrarNotasToolStripMenuItem"
        Me.RegistrarNotasToolStripMenuItem.Size = New System.Drawing.Size(264, 22)
        Me.RegistrarNotasToolStripMenuItem.Text = "Registrar notas"
        Me.RegistrarNotasToolStripMenuItem.Visible = False
        '
        'VerCalificacionesDeEstudianteToolStripMenuItem
        '
        Me.VerCalificacionesDeEstudianteToolStripMenuItem.Name = "VerCalificacionesDeEstudianteToolStripMenuItem"
        Me.VerCalificacionesDeEstudianteToolStripMenuItem.Size = New System.Drawing.Size(264, 22)
        Me.VerCalificacionesDeEstudianteToolStripMenuItem.Text = "Ver calificaciones de estudiante"
        Me.VerCalificacionesDeEstudianteToolStripMenuItem.Visible = False
        '
        'OrdenDeMeritoPorCursoToolStripMenuItem
        '
        Me.OrdenDeMeritoPorCursoToolStripMenuItem.Name = "OrdenDeMeritoPorCursoToolStripMenuItem"
        Me.OrdenDeMeritoPorCursoToolStripMenuItem.Size = New System.Drawing.Size(264, 22)
        Me.OrdenDeMeritoPorCursoToolStripMenuItem.Text = "Orden de merito por Curso"
        Me.OrdenDeMeritoPorCursoToolStripMenuItem.Visible = False
        '
        'PermisosToolStripMenuItem
        '
        Me.PermisosToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MatenimientoToolStripMenuItem})
        Me.PermisosToolStripMenuItem.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PermisosToolStripMenuItem.Name = "PermisosToolStripMenuItem"
        Me.PermisosToolStripMenuItem.Size = New System.Drawing.Size(147, 20)
        Me.PermisosToolStripMenuItem.Text = "Módulos(Formularios)"
        Me.PermisosToolStripMenuItem.Visible = False
        '
        'MatenimientoToolStripMenuItem
        '
        Me.MatenimientoToolStripMenuItem.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MatenimientoToolStripMenuItem.Name = "MatenimientoToolStripMenuItem"
        Me.MatenimientoToolStripMenuItem.Size = New System.Drawing.Size(163, 22)
        Me.MatenimientoToolStripMenuItem.Text = "Mantenimiento"
        '
        'TipoDeUsuariosToolStripMenuItem
        '
        Me.TipoDeUsuariosToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MantenimientoToolStripMenuItem})
        Me.TipoDeUsuariosToolStripMenuItem.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TipoDeUsuariosToolStripMenuItem.Name = "TipoDeUsuariosToolStripMenuItem"
        Me.TipoDeUsuariosToolStripMenuItem.Size = New System.Drawing.Size(114, 20)
        Me.TipoDeUsuariosToolStripMenuItem.Text = "Tipo de usuarios"
        Me.TipoDeUsuariosToolStripMenuItem.Visible = False
        '
        'MantenimientoToolStripMenuItem
        '
        Me.MantenimientoToolStripMenuItem.Name = "MantenimientoToolStripMenuItem"
        Me.MantenimientoToolStripMenuItem.Size = New System.Drawing.Size(163, 22)
        Me.MantenimientoToolStripMenuItem.Text = "Mantenimiento"
        '
        'UsuariosToolStripMenuItem
        '
        Me.UsuariosToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MantenimientoToolStripMenuItem1})
        Me.UsuariosToolStripMenuItem.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UsuariosToolStripMenuItem.Name = "UsuariosToolStripMenuItem"
        Me.UsuariosToolStripMenuItem.Size = New System.Drawing.Size(68, 20)
        Me.UsuariosToolStripMenuItem.Text = "Usuarios"
        Me.UsuariosToolStripMenuItem.Visible = False
        '
        'MantenimientoToolStripMenuItem1
        '
        Me.MantenimientoToolStripMenuItem1.Name = "MantenimientoToolStripMenuItem1"
        Me.MantenimientoToolStripMenuItem1.Size = New System.Drawing.Size(163, 22)
        Me.MantenimientoToolStripMenuItem1.Text = "Mantenimiento"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(305, 573)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(288, 21)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Estudiante: José Rosvel Carrera Sánchez"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(504, 594)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(89, 44)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "USS"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(88, 40)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(87, 24)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Usuario:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(12, 74)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(163, 24)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Tipo de usuario:"
        '
        'lblusuario
        '
        Me.lblusuario.AutoSize = True
        Me.lblusuario.BackColor = System.Drawing.Color.Transparent
        Me.lblusuario.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblusuario.ForeColor = System.Drawing.Color.Blue
        Me.lblusuario.Location = New System.Drawing.Point(172, 40)
        Me.lblusuario.Name = "lblusuario"
        Me.lblusuario.Size = New System.Drawing.Size(0, 24)
        Me.lblusuario.TabIndex = 5
        '
        'lbltipousuario
        '
        Me.lbltipousuario.AutoSize = True
        Me.lbltipousuario.BackColor = System.Drawing.Color.Transparent
        Me.lbltipousuario.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltipousuario.ForeColor = System.Drawing.Color.Blue
        Me.lbltipousuario.Location = New System.Drawing.Point(172, 74)
        Me.lbltipousuario.Name = "lbltipousuario"
        Me.lbltipousuario.Size = New System.Drawing.Size(0, 24)
        Me.lbltipousuario.TabIndex = 6
        '
        'btncerrarsistema
        '
        Me.btncerrarsistema.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.btncerrarsistema.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btncerrarsistema.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncerrarsistema.ForeColor = System.Drawing.Color.White
        Me.btncerrarsistema.Location = New System.Drawing.Point(789, 40)
        Me.btncerrarsistema.Name = "btncerrarsistema"
        Me.btncerrarsistema.Size = New System.Drawing.Size(126, 30)
        Me.btncerrarsistema.TabIndex = 7
        Me.btncerrarsistema.Text = "Cerrar Sistema"
        Me.btncerrarsistema.UseVisualStyleBackColor = False
        '
        'frmprincipal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(927, 680)
        Me.ControlBox = False
        Me.Controls.Add(Me.btncerrarsistema)
        Me.Controls.Add(Me.lbltipousuario)
        Me.Controls.Add(Me.lblusuario)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmprincipal"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "frmprincipal"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents GruposToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AulasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AsignaturaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EstudianteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TiposDeEvaluacionesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MatriculaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MAtricularToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AlumnosMatriculadosPorAulaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CalificacionesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RegistrarNotasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VerCalificacionesDeEstudianteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OrdenDeMeritoPorCursoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents PermisosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MatenimientoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TipoDeUsuariosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MantenimientoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UsuariosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MantenimientoToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lblusuario As Label
    Friend WithEvents lbltipousuario As Label
    Friend WithEvents btncerrarsistema As Button
End Class
