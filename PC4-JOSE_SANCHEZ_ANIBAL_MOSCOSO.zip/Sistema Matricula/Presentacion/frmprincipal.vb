﻿Public Class frmprincipal
    Private Sub GruposToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GruposToolStripMenuItem.Click
        frmGrupo.ShowDialog()


    End Sub

    Private Sub AulasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AulasToolStripMenuItem.Click
        frmAula.ShowDialog()
    End Sub

    Private Sub AsignaturaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AsignaturaToolStripMenuItem.Click
        frmAsignatura.ShowDialog()
    End Sub

    Private Sub EstudianteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EstudianteToolStripMenuItem.Click
        frmEstudiante.ShowDialog()
    End Sub

    Private Sub TiposDeEvaluacionesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TiposDeEvaluacionesToolStripMenuItem.Click
        frmtipoEvaluacion.ShowDialog()
    End Sub

    Private Sub MAtricularToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MAtricularToolStripMenuItem.Click
        frmMatricula.ShowDialog()
    End Sub

    Private Sub AlumnosMatriculadosPorAulaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AlumnosMatriculadosPorAulaToolStripMenuItem.Click
        frmmatriculadosporaula.ShowDialog()
    End Sub

    Private Sub RegistrarNotasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RegistrarNotasToolStripMenuItem.Click
        frmcalificacion.ShowDialog()
    End Sub

    Private Sub VerCalificacionesDeEstudianteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VerCalificacionesDeEstudianteToolStripMenuItem.Click
        frmcalificacionesdeesudiante.ShowDialog()
    End Sub

    Private Sub OrdenDeMeritoPorCursoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OrdenDeMeritoPorCursoToolStripMenuItem.Click
        frmordenmerito.ShowDialog()
    End Sub

    Private Sub MatenimientoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MatenimientoToolStripMenuItem.Click
        frmmodulo.ShowDialog()
    End Sub

    Private Sub MantenimientoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MantenimientoToolStripMenuItem.Click
        frmtipousuario.ShowDialog()
    End Sub

    Private Sub MantenimientoToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles MantenimientoToolStripMenuItem1.Click
        frmusuario.ShowDialog()
    End Sub



    Private Sub frmprincipal_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        permisos()
    End Sub

    Sub permisos()
        lblusuario.Text = frmlogin.usuario
        lbltipousuario.Text = frmlogin.tipousuario
        For index = 0 To frmlogin.permisos.Count - 1
            If frmlogin.permisos(index).ToString = "frmmodulo" Then
                Me.PermisosToolStripMenuItem.Visible = True
            End If
            If frmlogin.permisos(index).ToString = "frmGrupo" Then
                Me.GruposToolStripMenuItem.Visible = True
            End If
            If frmlogin.permisos(index).ToString = "frmAula" Then
                Me.AulasToolStripMenuItem.Visible = True
            End If
            If frmlogin.permisos(index).ToString = "frmAsignatura" Then
                Me.AsignaturaToolStripMenuItem.Visible = True
            End If
            If frmlogin.permisos(index).ToString = "frmEstudiante" Then
                Me.EstudianteToolStripMenuItem.Visible = True
            End If
            If frmlogin.permisos(index).ToString = "frmtipoEvaluacion" Then
                Me.TiposDeEvaluacionesToolStripMenuItem.Visible = True
            End If
            If frmlogin.permisos(index).ToString = "frmcalificacion" Then
                Me.CalificacionesToolStripMenuItem.Visible = True
                Me.RegistrarNotasToolStripMenuItem.Visible = True
            End If
            If frmlogin.permisos(index).ToString = "frmMatricula" Then
                Me.MatriculaToolStripMenuItem.Visible = True
                Me.MAtricularToolStripMenuItem.Visible = True
            End If
            If frmlogin.permisos(index).ToString = "frmmatriculadosporaula" Then
                Me.AlumnosMatriculadosPorAulaToolStripMenuItem.Visible = True
            End If
            If frmlogin.permisos(index).ToString = "frmcalificacionesdeestudiante" Then
                Me.CalificacionesToolStripMenuItem.Visible = True
                Me.VerCalificacionesDeEstudianteToolStripMenuItem.Visible = True
            End If
            If frmlogin.permisos(index).ToString = "frmordenmerito" Then
                Me.CalificacionesToolStripMenuItem.Visible = True
                Me.OrdenDeMeritoPorCursoToolStripMenuItem.Visible = True
            End If
            If frmlogin.permisos(index).ToString = "frmmodulo" Then
                Me.PermisosToolStripMenuItem.Visible = True
                Me.MatenimientoToolStripMenuItem.Visible = True
            End If
            If frmlogin.permisos(index).ToString = "frmtipousuario" Then
                Me.TipoDeUsuariosToolStripMenuItem.Visible = True
                Me.MantenimientoToolStripMenuItem.Visible = True
            End If
            If frmlogin.permisos(index).ToString = "frmtipousuario" Then
                Me.TipoDeUsuariosToolStripMenuItem.Visible = True
                Me.MantenimientoToolStripMenuItem.Visible = True
            End If
            If frmlogin.permisos(index).ToString = "frmusuario" Then
                Me.UsuariosToolStripMenuItem.Visible = True
                Me.MantenimientoToolStripMenuItem1.Visible = True
            End If
        Next
    End Sub

    Private Sub btncerrarsistema_Click(sender As Object, e As EventArgs) Handles btncerrarsistema.Click
        If (MessageBox.Show("¿Desea salir del sistema?", "titulo", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) = DialogResult.Yes) Then
            Application.Exit()
        End If

    End Sub
End Class