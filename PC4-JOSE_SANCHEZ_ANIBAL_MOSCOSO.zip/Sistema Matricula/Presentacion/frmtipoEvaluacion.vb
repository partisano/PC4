﻿Imports Negocio
Imports Entidades
Public Class frmtipoEvaluacion
    Dim tipoevaluacionN As New clstipoevaluacionN
    Dim tipoevaluacionE As New clstipoEvaluacionE
    Private Sub btnregistrar_Click(sender As Object, e As EventArgs) Handles btnregistrar.Click
        If txtcodigo.Text.Trim <> String.Empty Then
            MsgBox("Debe limpiar el código")
            btnLimpiar.Focus()
            Exit Sub
        End If

        If txtdescripcion.Text.Trim = String.Empty Then
            MsgBox("Ingrese descripción para el tipo de evaluación")
            txtdescripcion.Focus()
            Exit Sub
        End If


        tipoevaluacionE.Descripcion1 = txtdescripcion.Text
        tipoevaluacionN.registrartipoevaluacionN(tipoevaluacionE)
        MsgBox("Registro OK")
        dtggrupo.DataSource = tipoevaluacionN.listartipoevaluacionN()
        txtdescripcion.Clear()
    End Sub

    Private Sub btnmodificar_Click(sender As Object, e As EventArgs) Handles btnmodificar.Click
        If txtcodigo.Text.Trim = String.Empty Then
            MsgBox("Seleccione elemento de la lista")
            dtggrupo.Focus()
            Exit Sub
        End If
        If txtdescripcion.Text.Trim = String.Empty Then
            MsgBox("Ingrese letra de grupo")
            txtdescripcion.Focus()
            Exit Sub
        End If

        tipoevaluacionE.Idtipoevaluacion1 = txtcodigo.Text
        tipoevaluacionE.Descripcion1 = txtdescripcion.Text
        tipoevaluacionN.modificartipoevaluacionN(tipoevaluacionE)
        MsgBox("Modificado OK")
        dtggrupo.DataSource = tipoevaluacionN.listartipoevaluacionN()
        txtcodigo.Clear()
        txtdescripcion.Clear()
    End Sub

    Private Sub btneliminar_Click(sender As Object, e As EventArgs) Handles btneliminar.Click
        If txtcodigo.Text.Trim = String.Empty Then
            MsgBox("Seleccione elemento de la lista")
            dtggrupo.Focus()
            Exit Sub
        End If
        tipoevaluacionE.Idtipoevaluacion1 = txtcodigo.Text
        tipoevaluacionN.eliminartipoevaluacionN(tipoevaluacionE)
        MsgBox("Eliminado OK")
        dtggrupo.DataSource = tipoevaluacionN.listartipoevaluacionN()
        txtcodigo.Clear()
        txtdescripcion.Clear()
    End Sub

    Private Sub btnLimpiar_Click(sender As Object, e As EventArgs) Handles btnLimpiar.Click
        txtcodigo.Clear()
        Me.txtdescripcion.Clear()
    End Sub

    Private Sub btnbuscar_Click(sender As Object, e As EventArgs) Handles btnbuscar.Click
        If txtbusqueda.Text.Trim = String.Empty Then
            dtggrupo.DataSource = tipoevaluacionN.listartipoevaluacionN()
        Else
            tipoevaluacionE.Busqueda1 = txtbusqueda.Text.Trim
            dtggrupo.DataSource = tipoevaluacionN.buscartipoevaluacionN(tipoevaluacionE)
        End If
    End Sub

    Private Sub dtggrupo_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dtggrupo.CellClick

        txtcodigo.Text = dtggrupo.Rows(e.RowIndex).Cells(0).Value 'Caputar el id de la persona seleccionada
        txtdescripcion.Text = dtggrupo.Rows(e.RowIndex).Cells(1).Value
    End Sub

    Private Sub frmtipoEvaluacion_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim encontro As Boolean = False
        For index = 0 To frmlogin.permisos.Count - 1
            If frmlogin.permisos(index).ToString = "frmtipoEvaluacion" Then
                encontro = True
            End If
        Next
        If encontro <> True Then
            Close()
        End If
    End Sub
End Class