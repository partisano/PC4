﻿Imports Negocio
Imports Entidades
Public Class frmtipousuario
    Dim tipousuarioE As New clstipousuarioE
    Dim tipousuarioN As New clstipousuarioN
    Dim elementoE As New clselementoE
    Dim elementoN As New clselementoN
    Dim detallepermisoE As New clsdetallepermisoE
    Dim detallepermisoN As New clsdetallepermisoN
    Private Sub txtcodigo_TextChanged(sender As Object, e As EventArgs) Handles txtcodigo.TextChanged

    End Sub

    Private Sub btnregistrar_Click(sender As Object, e As EventArgs) Handles btnregistrar.Click
        Try
            If txtcodigo.Text.Trim <> String.Empty Then
                MsgBox("Debe limpiar el código")
                btnLimpiar.Focus()
                Exit Sub
            End If

            If txtnombre.Text.Trim = String.Empty Then
                MsgBox("Ingrese descripción de tipousuario")
                txtnombre.Focus()
                Exit Sub
            End If
            tipousuarioE.Descripcion1 = txtnombre.Text

            Dim tipousuariore As Integer
            tipousuariore = tipousuarioN.registrartipousuarioN(tipousuarioE)

            If tipousuariore.ToString <> Nothing Then
                For index = 0 To dtgelementos.Rows.Count - 1
                    If dtgelementos.Rows(index).Cells(0).Value = True Then
                        detallepermisoE.Idelemento1 = dtgelementos.Rows(index).Cells(1).Value
                        detallepermisoE.Idtipousuario1 = tipousuariore
                        detallepermisoN.registrardetallepermisoN(detallepermisoE)
                    End If
                Next
                limpiar()
                MsgBox("Registro OK")
            Else
                MsgBox("Error al registrar")

            End If
            dtgdatos.DataSource = tipousuarioN.listartipousuarioN()
            txtnombre.Clear()


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnmodificar_Click(sender As Object, e As EventArgs) Handles btnmodificar.Click
        Try
            If txtcodigo.Text.Trim = String.Empty Then
                MsgBox("Debe eleccionar el tipo de usuario a modificar")
                dtgdatos.Focus()
                Exit Sub
            End If

            If txtnombre.Text.Trim = String.Empty Then
                MsgBox("Ingrese descripción de tipousuario")
                txtnombre.Focus()
                Exit Sub
            End If
            tipousuarioE.Idtipousuario1 = txtcodigo.Text
            tipousuarioE.Descripcion1 = txtnombre.Text

            tipousuarioN.modificartipousuarioN(tipousuarioE)

            If txtcodigo.Text.ToString <> Nothing Then
                detallepermisoE.Idtipousuario1 = txtcodigo.Text
                detallepermisoN.eliminardetallepermisoN(detallepermisoE)
                For index = 0 To dtgelementos.Rows.Count - 1
                    If dtgelementos.Rows(index).Cells(0).Value = True Then
                        detallepermisoE.Idelemento1 = dtgelementos.Rows(index).Cells(1).Value
                        detallepermisoE.Idtipousuario1 = txtcodigo.Text
                        detallepermisoN.registrardetallepermisoN(detallepermisoE)
                    End If
                Next
                limpiar()
                MsgBox("Modificación OK, para comprobar los nuevos cambios tiene que cerrar e ingresar nuevamente al sistema")
            Else
                MsgBox("Error al modificar")

            End If
            dtgdatos.DataSource = tipousuarioN.listartipousuarioN()
            txtnombre.Clear()


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub
    Private Sub btneliminar_Click(sender As Object, e As EventArgs) Handles btneliminar.Click
        Try
            If txtcodigo.Text.Trim = String.Empty Then
                MsgBox("Seleccione elemento de la lista de tipo de usuarios")
                dtgdatos.Focus()
                Exit Sub
            End If
            If frmlogin.idtipousuario = txtcodigo.Text.Trim Then
                MsgBox("ELiminación denegada")
                Exit Sub
            End If
            tipousuarioE.Idtipousuario1 = txtcodigo.Text
            tipousuarioN.eliminartipousuarioN(tipousuarioE)
        MsgBox("ELiminado OK")
        dtgdatos.DataSource = tipousuarioN.listartipousuarioN()
        limpiar()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub
    Private Sub btnLimpiar_Click(sender As Object, e As EventArgs) Handles btnLimpiar.Click
        limpiar()
    End Sub
    Sub limpiar()
        txtcodigo.Clear()
        txtnombre.Clear()
        For index = 0 To dtgelementos.Rows.Count - 1
            dtgelementos.Rows(index).Cells(0).Value = False

        Next
    End Sub
    Private Sub dtgdatos_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dtgdatos.CellClick
        txtcodigo.Text = dtgdatos.Rows(e.RowIndex).Cells(0).Value 'Caputar el id de la persona seleccionada
        txtnombre.Text = dtgdatos.Rows(e.RowIndex).Cells(1).Value
        detallepermisoE.Idtipousuario1 = txtcodigo.Text
        Dim dt As New DataTable
        dt = detallepermisoN.buscardetallepermisoN(detallepermisoE)
        Dim verdaderos As ArrayList = New ArrayList()
        For index2 = 0 To dtgelementos.Rows.Count - 1
            dtgelementos.Rows(index2).Cells(0).Value = False
            For index = 0 To dt.Rows.Count - 1

                If dt.Rows(index)(0) = dtgelementos.Rows(index2).Cells(1).Value Then
                    verdaderos.Add(index2)

                End If
            Next
        Next
        For i = 0 To verdaderos.Count - 1
            dtgelementos.Rows(verdaderos(i)).Cells(0).Value = True
        Next

    End Sub

    Private Sub frmtipousuario_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim encontro As Boolean = False
        For index = 0 To frmlogin.permisos.Count - 1
            If frmlogin.permisos(index).ToString = "frmtipousuario" Then
                encontro = True
            End If
        Next
        If encontro <> True Then
            Close()
        End If
        dtgelementos.DataSource = elementoN.listarelementoN()
        dtgdatos.DataSource = tipousuarioN.listartipousuarioN()
    End Sub


    Private Sub btnbuscar_Click(sender As Object, e As EventArgs) Handles btnbuscar.Click
        If txtbusqueda.Text.Trim = String.Empty Then
            dtgdatos.DataSource = tipousuarioN.listartipousuarioN()
        Else
            tipousuarioE.Busqueda1 = txtbusqueda.Text.Trim
            dtgdatos.DataSource = tipousuarioN.buscartipousuarioN(tipousuarioE)
        End If
    End Sub
End Class