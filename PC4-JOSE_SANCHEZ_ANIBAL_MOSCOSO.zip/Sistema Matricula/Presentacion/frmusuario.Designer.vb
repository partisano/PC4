﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmusuario
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.cbxtipousuario = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnLimpiar = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnbuscar = New System.Windows.Forms.Button()
        Me.txtbusqueda = New System.Windows.Forms.TextBox()
        Me.btneliminar = New System.Windows.Forms.Button()
        Me.btnmodificar = New System.Windows.Forms.Button()
        Me.txtcodigo = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.dtgdatos = New System.Windows.Forms.DataGridView()
        Me.cmsverpermisos = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.VerPermisosDelUsuarioSeleccionadoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnregistrar = New System.Windows.Forms.Button()
        Me.txtusuario = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtclave = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        CType(Me.dtgdatos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.cmsverpermisos.SuspendLayout()
        Me.SuspendLayout()
        '
        'cbxtipousuario
        '
        Me.cbxtipousuario.FormattingEnabled = True
        Me.cbxtipousuario.Location = New System.Drawing.Point(235, 82)
        Me.cbxtipousuario.Name = "cbxtipousuario"
        Me.cbxtipousuario.Size = New System.Drawing.Size(121, 21)
        Me.cbxtipousuario.TabIndex = 41
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(236, 60)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(135, 13)
        Me.Label5.TabIndex = 40
        Me.Label5.Text = "Seleccione tipo de usuario:"
        '
        'btnLimpiar
        '
        Me.btnLimpiar.Location = New System.Drawing.Point(281, 132)
        Me.btnLimpiar.Name = "btnLimpiar"
        Me.btnLimpiar.Size = New System.Drawing.Size(75, 23)
        Me.btnLimpiar.TabIndex = 37
        Me.btnLimpiar.Text = "Limpiar"
        Me.btnLimpiar.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnbuscar)
        Me.GroupBox1.Controls.Add(Me.txtbusqueda)
        Me.GroupBox1.Location = New System.Drawing.Point(9, 161)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(461, 46)
        Me.GroupBox1.TabIndex = 36
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Buscar"
        '
        'btnbuscar
        '
        Me.btnbuscar.Location = New System.Drawing.Point(272, 16)
        Me.btnbuscar.Name = "btnbuscar"
        Me.btnbuscar.Size = New System.Drawing.Size(75, 23)
        Me.btnbuscar.TabIndex = 1
        Me.btnbuscar.Text = "&Buscar"
        Me.btnbuscar.UseVisualStyleBackColor = True
        '
        'txtbusqueda
        '
        Me.txtbusqueda.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtbusqueda.Location = New System.Drawing.Point(6, 19)
        Me.txtbusqueda.Name = "txtbusqueda"
        Me.txtbusqueda.Size = New System.Drawing.Size(249, 20)
        Me.txtbusqueda.TabIndex = 0
        '
        'btneliminar
        '
        Me.btneliminar.Location = New System.Drawing.Point(200, 132)
        Me.btneliminar.Name = "btneliminar"
        Me.btneliminar.Size = New System.Drawing.Size(75, 23)
        Me.btneliminar.TabIndex = 35
        Me.btneliminar.Text = "&Eliminar"
        Me.btneliminar.UseVisualStyleBackColor = True
        '
        'btnmodificar
        '
        Me.btnmodificar.Location = New System.Drawing.Point(119, 133)
        Me.btnmodificar.Name = "btnmodificar"
        Me.btnmodificar.Size = New System.Drawing.Size(75, 23)
        Me.btnmodificar.TabIndex = 34
        Me.btnmodificar.Text = "&Modificar"
        Me.btnmodificar.UseVisualStyleBackColor = True
        '
        'txtcodigo
        '
        Me.txtcodigo.Location = New System.Drawing.Point(82, 31)
        Me.txtcodigo.Name = "txtcodigo"
        Me.txtcodigo.ReadOnly = True
        Me.txtcodigo.Size = New System.Drawing.Size(80, 20)
        Me.txtcodigo.TabIndex = 33
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(27, 34)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(43, 13)
        Me.Label3.TabIndex = 32
        Me.Label3.Text = "Código:"
        '
        'dtgdatos
        '
        Me.dtgdatos.AllowUserToAddRows = False
        Me.dtgdatos.AllowUserToDeleteRows = False
        Me.dtgdatos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dtgdatos.ContextMenuStrip = Me.cmsverpermisos
        Me.dtgdatos.Location = New System.Drawing.Point(4, 231)
        Me.dtgdatos.Name = "dtgdatos"
        Me.dtgdatos.ReadOnly = True
        Me.dtgdatos.Size = New System.Drawing.Size(466, 177)
        Me.dtgdatos.TabIndex = 31
        Me.dtgdatos.VirtualMode = True
        '
        'cmsverpermisos
        '
        Me.cmsverpermisos.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.VerPermisosDelUsuarioSeleccionadoToolStripMenuItem})
        Me.cmsverpermisos.Name = "cmsverpermisos"
        Me.cmsverpermisos.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.cmsverpermisos.Size = New System.Drawing.Size(276, 26)
        '
        'VerPermisosDelUsuarioSeleccionadoToolStripMenuItem
        '
        Me.VerPermisosDelUsuarioSeleccionadoToolStripMenuItem.Name = "VerPermisosDelUsuarioSeleccionadoToolStripMenuItem"
        Me.VerPermisosDelUsuarioSeleccionadoToolStripMenuItem.Size = New System.Drawing.Size(275, 22)
        Me.VerPermisosDelUsuarioSeleccionadoToolStripMenuItem.Text = "Ver permisos del usuario seleccionado"
        '
        'btnregistrar
        '
        Me.btnregistrar.Location = New System.Drawing.Point(38, 133)
        Me.btnregistrar.Name = "btnregistrar"
        Me.btnregistrar.Size = New System.Drawing.Size(75, 23)
        Me.btnregistrar.TabIndex = 30
        Me.btnregistrar.Text = "&Registrar"
        Me.btnregistrar.UseVisualStyleBackColor = True
        '
        'txtusuario
        '
        Me.txtusuario.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtusuario.Location = New System.Drawing.Point(80, 57)
        Me.txtusuario.MaxLength = 20
        Me.txtusuario.Name = "txtusuario"
        Me.txtusuario.Size = New System.Drawing.Size(138, 20)
        Me.txtusuario.TabIndex = 29
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(27, 60)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(46, 13)
        Me.Label2.TabIndex = 28
        Me.Label2.Text = "Usuario:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(157, 10)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(128, 13)
        Me.Label1.TabIndex = 27
        Me.Label1.Text = "Mantenimiento USUARIO"
        '
        'txtclave
        '
        Me.txtclave.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtclave.Location = New System.Drawing.Point(80, 87)
        Me.txtclave.MaxLength = 20
        Me.txtclave.Name = "txtclave"
        Me.txtclave.Size = New System.Drawing.Size(138, 20)
        Me.txtclave.TabIndex = 43
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(38, 90)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(37, 13)
        Me.Label4.TabIndex = 42
        Me.Label4.Text = "Clave:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Green
        Me.Label6.Location = New System.Drawing.Point(3, 215)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(474, 13)
        Me.Label6.TabIndex = 46
        Me.Label6.Text = "Clic derecho (Anti clic) en usuario seleccionado para ver sus permisos concedidos" &
    ""
        '
        'frmusuario
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(491, 420)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtclave)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.cbxtipousuario)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.btnLimpiar)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btneliminar)
        Me.Controls.Add(Me.btnmodificar)
        Me.Controls.Add(Me.txtcodigo)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.dtgdatos)
        Me.Controls.Add(Me.btnregistrar)
        Me.Controls.Add(Me.txtusuario)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmusuario"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "frmusuario"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.dtgdatos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.cmsverpermisos.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents cbxtipousuario As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents btnLimpiar As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btnbuscar As Button
    Friend WithEvents txtbusqueda As TextBox
    Friend WithEvents btneliminar As Button
    Friend WithEvents btnmodificar As Button
    Friend WithEvents txtcodigo As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents dtgdatos As DataGridView
    Friend WithEvents btnregistrar As Button
    Friend WithEvents txtusuario As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txtclave As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents cmsverpermisos As ContextMenuStrip
    Friend WithEvents VerPermisosDelUsuarioSeleccionadoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Label6 As Label
End Class
