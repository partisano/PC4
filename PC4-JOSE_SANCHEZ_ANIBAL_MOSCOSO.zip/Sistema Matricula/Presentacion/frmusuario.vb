﻿Imports Negocio
Imports Entidades
Public Class frmusuario
    Dim objetotipousuario As New clstipousuarioN
    Dim usuarioE As New clsusuarioE
    Dim usuarioN As New clsusuarioN
    Public tipousuarioseleccionado As Integer
    Public nombretipousuarioseleccionado As String
    Public usuarioseleccionado As String
    Private Sub frmusuario_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim encontro As Boolean = False
        For index = 0 To frmlogin.permisos.Count - 1
            If frmlogin.permisos(index).ToString = "frmusuario" Then
                encontro = True
            End If
        Next
        If encontro <> True Then
            Close()
        End If
        llenarcombotipousuario()
        dtgdatos.DataSource = usuarioN.listarusuarioN()
    End Sub

    Sub llenarcombotipousuario()
        cbxtipousuario.DisplayMember = "descripcion"
        cbxtipousuario.ValueMember = "idtipousuario"
        cbxtipousuario.DataSource = objetotipousuario.listartipousuarioN
    End Sub

    Private Sub btnregistrar_Click(sender As Object, e As EventArgs) Handles btnregistrar.Click
        Try
            If txtcodigo.Text.Trim <> String.Empty Then
            MsgBox("Debe limpiar el código")
            btnLimpiar.Focus()
            Exit Sub
        End If

        If txtusuario.Text.Trim = String.Empty Then
            MsgBox("Ingrese usuario")
            txtusuario.Focus()
            Exit Sub
        End If
        If txtclave.Text.Trim = String.Empty Then
            MsgBox("Ingrese una clave")
            txtclave.Focus()
            Exit Sub
        End If

        usuarioE.Usuario1 = txtusuario.Text
        usuarioE.Clave1 = txtclave.Text
        usuarioE.Idtipousuario1 = cbxtipousuario.SelectedValue
        usuarioN.registrarusuarioN(usuarioE)
        MsgBox("Registro OK")
        dtgdatos.DataSource = usuarioN.listarusuarioN()
        txtusuario.Clear()
        txtclave.Clear()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub dtgdatos_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dtgdatos.CellClick
        txtcodigo.Text = dtgdatos.Rows(e.RowIndex).Cells(0).Value 'Caputar el id de la persona seleccionada
        txtusuario.Text = dtgdatos.Rows(e.RowIndex).Cells(1).Value
        txtclave.Text = dtgdatos.Rows(e.RowIndex).Cells(2).Value
        cbxtipousuario.Text = dtgdatos.Rows(e.RowIndex).Cells(3).Value
    End Sub

    Private Sub btnLimpiar_Click(sender As Object, e As EventArgs) Handles btnLimpiar.Click
        txtcodigo.Clear()
        txtusuario.Clear()
        txtclave.Clear()
    End Sub

    Private Sub btnmodificar_Click(sender As Object, e As EventArgs) Handles btnmodificar.Click
        Try
            If txtcodigo.Text.Trim = String.Empty Then
            MsgBox("Seleccione elemento de la lista")
            dtgdatos.Focus()
            Exit Sub
        End If
        If txtusuario.Text.Trim = String.Empty Then
            MsgBox("Ingrese usuario")
            txtusuario.Focus()
            Exit Sub
        End If
        If txtclave.Text.Trim = String.Empty Then
            MsgBox("Ingrese una clave")
            txtclave.Focus()
            Exit Sub
        End If
        usuarioE.Idusuario1 = txtcodigo.Text
        usuarioE.Usuario1 = txtusuario.Text
        usuarioE.Clave1 = txtclave.Text
        usuarioE.Idtipousuario1 = cbxtipousuario.SelectedValue
        usuarioN.modificarusuarioN(usuarioE)
            MsgBox("Modificación OK, para comprobar los nuevos cambios tiene que cerrar e ingresar nuevamente al sistema")
            dtgdatos.DataSource = usuarioN.listarusuarioN()
            txtcodigo.Clear()
        txtusuario.Clear()
            txtclave.Clear()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub btneliminar_Click(sender As Object, e As EventArgs) Handles btneliminar.Click
        Try
            If txtcodigo.Text.Trim = String.Empty Then
                MsgBox("Seleccione elemento de la lista")
                dtgdatos.Focus()
                Exit Sub
            End If
            If txtcodigo.Text.Trim = frmlogin.idusuario Then
                MsgBox("Eliminación denegada")

                Exit Sub
            End If
            usuarioE.Idusuario1 = txtcodigo.Text
        usuarioN.eliminarusuarioN(usuarioE)
        MsgBox("ELiminado OK")
        dtgdatos.DataSource = usuarioN.listarusuarioN()
        txtcodigo.Clear()
        txtusuario.Clear()
            txtclave.Clear()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub btnbuscar_Click(sender As Object, e As EventArgs) Handles btnbuscar.Click
        If txtbusqueda.Text.Trim = String.Empty Then
            dtgdatos.DataSource = usuarioN.listarusuarioN()
        Else
            usuarioE.Busqueda1 = txtbusqueda.Text.Trim
            dtgdatos.DataSource = usuarioN.buscarusuarioN(usuarioE)
        End If
    End Sub

    Private Sub VerPermisosDelUsuarioSeleccionadoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VerPermisosDelUsuarioSeleccionadoToolStripMenuItem.Click
        frmpermisosxusuario.ShowDialog()

    End Sub



    Private Sub dtgdatos_MouseDown(sender As Object, e As MouseEventArgs) Handles dtgdatos.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Right Then
            With Me.dtgdatos
                Dim Hitest As DataGridView.HitTestInfo = .HitTest(e.X, e.Y)
                If Hitest.Type = DataGridViewHitTestType.Cell Then
                    .CurrentCell = .Rows(Hitest.RowIndex).Cells(Hitest.ColumnIndex)
                    usuarioseleccionado = dtgdatos.CurrentRow.Cells(1).Value
                    nombretipousuarioseleccionado = dtgdatos.CurrentRow.Cells(3).Value
                    tipousuarioseleccionado = dtgdatos.CurrentRow.Cells(4).Value

                End If
            End With
        End If
    End Sub
End Class